﻿using Microsoft.Extensions.Configuration;
using Project.Common.Tools.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Project.Common.Tools
{
    public class EmailService : IEmailService
    {
        private readonly IConfiguration _configuration;

        public EmailService(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public async Task SendActivationEmailAsync(string toEmail, string activationLink)
        {
            MailMessage mail = new MailMessage();
            mail.To.Add(toEmail);
            mail.Subject = "BilgeHotel Aktivasyon Kodu";
            mail.Body = $"Hesabınızı aktif etmek için tıklayın: <a href='{activationLink}'>Aktivasyon</a>";
            mail.IsBodyHtml = true;
            mail.From = new MailAddress("bilgehotel@outlook.com");

            SmtpClient smtp = new SmtpClient("smtp.office365.com", 587);
            smtp.Credentials = new NetworkCredential("bilgehotel@outlook.com", "ŞİFRE");
            smtp.EnableSsl = true;

            await smtp.SendMailAsync(mail);
        }
    }
}
