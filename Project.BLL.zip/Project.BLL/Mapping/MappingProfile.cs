﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using Project.BLL.DtoClasses;
using Project.Entities.Enums;
using Project.Entities.Models;


namespace Project.BLL.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            // Entity -> DTO Dönüşümleri
            CreateMap<Reservation, ReservationDto>().ReverseMap();
            CreateMap<User, UserDto>().ReverseMap();
            CreateMap<Room, RoomDto>().ReverseMap();
            CreateMap<Employee, EmployeeDto>().ReverseMap();
            CreateMap<Payment, PaymentDto>().ReverseMap();
            CreateMap<BackupLog, BackupLogDto>().ReverseMap();
            CreateMap<Campaign, CampaignDto>().ReverseMap();
            CreateMap<ComplaintLog, ComplaintLogDto>().ReverseMap();
            CreateMap<Customer, CustomerDto>().ReverseMap();
            CreateMap<EarlyReservationDiscount, EarlyReservationDiscountDto>().ReverseMap();
            CreateMap<EmployeeShift, EmployeeShiftDto>().ReverseMap();
            CreateMap<ExchangeRate, ExchangeRateDto>().ReverseMap();
            CreateMap<GuestVisitLog, GuestVisitLogDto>().ReverseMap();
            CreateMap<OrderDetail, OrderDetailDto>().ReverseMap();
            CreateMap<Order, OrderDto>().ReverseMap();
            CreateMap<Product, ProductDto>().ReverseMap();
            CreateMap<ReportLog, ReportLogDto>().ReverseMap();
            CreateMap<Review, ReviewDto>().ReverseMap();
            CreateMap<RoomCleaningSchedule, RoomCleaningScheduleDto>().ReverseMap();
            CreateMap<RoomImage, RoomImageDto>().ReverseMap();
            CreateMap<RoomMaintenance, RoomMaintenanceDto>().ReverseMap();
            CreateMap<ExtraExpense, ExtraExpenseDto>().ReverseMap();
            CreateMap<UserProfile, UserProfileDto>().ReverseMap();


        }
    }
}
