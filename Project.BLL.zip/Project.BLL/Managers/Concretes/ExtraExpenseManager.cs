﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class ExtraExpenseManager : BaseManager<ExtraExpenseDto, ExtraExpense>, IExtraExpenseManager
    {
        private readonly IExtraExpenseRepository _extraExpenseRepository;
        private readonly IReservationRepository _reservationRepository;
        private readonly IMapper _mapper;

        public ExtraExpenseManager(IExtraExpenseRepository extraExpenseRepository, IReservationRepository reservationRepository, IMapper mapper)
            : base(extraExpenseRepository, mapper)
        {
            _extraExpenseRepository = extraExpenseRepository;
            _reservationRepository = reservationRepository;
            _mapper = mapper;
        }

        public async Task<int> AddExtraExpenseAsync(int reservationId, decimal unitPrice, string description)
        {
            var reservation = await _reservationRepository.GetByIdAsync(reservationId);
            if (reservation == null)
                throw new Exception("Rezervasyon bulunamadı!");

            var extraExpense = new ExtraExpense
            {
                ReservationId = reservationId,
                UnitPrice = unitPrice,
                Description = description,
                ExpenseDate = DateTime.UtcNow
            };

            await _extraExpenseRepository.AddAsync(extraExpense);
            return extraExpense.Id;
        }

        public async Task<bool> DeleteExtraExpenseAsync(int expenseId)
        {
            var extraExpense = await _extraExpenseRepository.GetByIdAsync(expenseId);
            if (extraExpense == null)
                return false;

            await _extraExpenseRepository.RemoveAsync(extraExpense);
            return true;
        }

        public async Task<List<ExtraExpenseDto>> GetExtraExpensesByReservationAsync(int reservationId)
        {
            var expenses = await _extraExpenseRepository.GetAllAsync(e => e.ReservationId == reservationId);
            return _mapper.Map<List<ExtraExpenseDto>>(expenses);
        }

        public async Task<bool> UpdateExtraExpenseAsync(int expenseId, decimal unitPrice, string description)
        {
            var extraExpense = await _extraExpenseRepository.GetByIdAsync(expenseId);
            if (extraExpense == null)
                return false;

            extraExpense.UnitPrice = unitPrice;
            extraExpense.Description = description;
            await _extraExpenseRepository.UpdateAsync(extraExpense);

            return true;
        }
    }
}
