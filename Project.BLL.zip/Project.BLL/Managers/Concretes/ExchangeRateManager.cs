﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class ExchangeRateManager : BaseManager<ExchangeRateDto, ExchangeRate>, IExchangeRateManager
    {
        private readonly IExchangeRateRepository _exchangeRateRepository;
        private readonly IMapper _mapper;

        public ExchangeRateManager(IExchangeRateRepository exchangeRateRepository, IMapper mapper)
            : base(exchangeRateRepository, mapper)
        {
            _exchangeRateRepository = exchangeRateRepository;
            _mapper = mapper;
        }

        public async Task<decimal> ConvertCurrencyAsync(decimal amount, Currency from, Currency to)
        {
            if (from == to)
                return amount; // Aynı para birimi ise dönüşüm gereksiz

            var latestRate = (await _exchangeRateRepository.GetAllAsync(r => r.FromCurrency == from && r.ToCurrency == to))
                             .OrderByDescending(r => r.Date)
                             .FirstOrDefault();

            if (latestRate == null)
                throw new Exception("Döviz kuru bulunamadı.");

            return amount * latestRate.Rate; // ✅ Döviz çevirme işlemi
        }

        // ❌ Şimdilik API Çağrısını Yoruma Alalım
        /*
        public async Task FetchLatestExchangeRatesAsync()
        {
            string apiUrl = "https://api.exchangeratesapi.io/latest?base=USD";

            using (var httpClient = new HttpClient())
            {
                HttpResponseMessage response = await httpClient.GetAsync(apiUrl);
                if (!response.IsSuccessStatusCode)
                    throw new Exception("Döviz kuru API'ye erişilemedi.");

                string json = await response.Content.ReadAsStringAsync();
                var exchangeRates = JsonSerializer.Deserialize<ExchangeRateApiResponseDto>(json);

                if (exchangeRates?.Rates == null)
                    throw new Exception("API'den döviz kurları alınamadı.");

                foreach (var rate in exchangeRates.Rates)
                {
                    await UpdateExchangeRateAsync(Currency.USD, Enum.Parse<Currency>(rate.Key), rate.Value);
                }
            }
        }
        */

        // ✅ API Entegrasyonu Eklenene Kadar Geçici Metod
        public async Task AddManualExchangeRatesAsync()
        {
            await UpdateExchangeRateAsync(Currency.USD, Currency.EUR, 0.91m); // Örnek USD -> EUR kuru
            await UpdateExchangeRateAsync(Currency.USD, Currency.TRY, 32.5m); // Örnek USD -> TRY kuru
            await UpdateExchangeRateAsync(Currency.EUR, Currency.TRY, 35.6m); // Örnek EUR -> TRY kuru
        }

        public async Task UpdateExchangeRateAsync(Currency from, Currency to, decimal rate)
        {
            var existingRate = (await _exchangeRateRepository.GetAllAsync(r => r.FromCurrency == from && r.ToCurrency == to))
                               .OrderByDescending(r => r.Date)
                               .FirstOrDefault();

            if (existingRate != null)
            {
                var oldRate = new ExchangeRate
                {
                    FromCurrency = existingRate.FromCurrency,
                    ToCurrency = existingRate.ToCurrency,
                    Rate = existingRate.Rate,
                    Date = existingRate.Date
                };
                await _exchangeRateRepository.AddAsync(oldRate);

                existingRate.Rate = rate;
                existingRate.Date = DateTime.UtcNow;
                await _exchangeRateRepository.UpdateAsync(existingRate);
            }
            else
            {
                var newRate = new ExchangeRate
                {
                    FromCurrency = from,
                    ToCurrency = to,
                    Rate = rate,
                    Date = DateTime.UtcNow
                };

                await _exchangeRateRepository.AddAsync(newRate);
            }
        }

        public Task FetchLatestExchangeRatesAsync()
        {
            throw new NotImplementedException();
        }
    }
}
