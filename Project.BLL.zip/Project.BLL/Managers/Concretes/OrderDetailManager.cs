﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class OrderDetailManager:BaseManager<OrderDetailDto,OrderDetail>,IOrderDetailManager
    {
        private readonly IOrderDetailRepository _orderDetailRepository;
        private readonly IOrderRepository _orderRepository;
        private readonly IMapper _mapper;

        public OrderDetailManager(IOrderDetailRepository orderDetailRepository, IOrderRepository orderRepository, IMapper mapper)
            : base(orderDetailRepository, mapper)
        {
            _orderDetailRepository = orderDetailRepository;
            _orderRepository = orderRepository;
            _mapper = mapper;
        }

        public async Task<int> AddOrderDetailAsync(int orderId, OrderDetailDto orderDetailDto)
        {
            var order = await _orderRepository.GetByIdAsync(orderId);
            if (order == null)
                throw new Exception("Sipariş bulunamadı.");

            var orderDetail = _mapper.Map<OrderDetail>(orderDetailDto);
            orderDetail.OrderId = orderId;

            await _orderDetailRepository.AddAsync(orderDetail);
            return orderDetail.Id;
        }

        public async Task<bool> UpdateOrderDetailAsync(int orderDetailId, OrderDetailDto orderDetailDto)
        {
            var existingOrderDetail = await _orderDetailRepository.GetByIdAsync(orderDetailId);
            if (existingOrderDetail == null)
                return false;

            _mapper.Map(orderDetailDto, existingOrderDetail);
            await _orderDetailRepository.UpdateAsync(existingOrderDetail);

            return true;
        }

        public async Task<List<OrderDetailDto>> GetOrderDetailsByOrderIdAsync(int orderId)
        {
            var orderDetails = await _orderDetailRepository.GetAllAsync(od => od.OrderId == orderId);
            return _mapper.Map<List<OrderDetailDto>>(orderDetails);
        }

        public async Task<bool> DeleteOrderDetailAsync(int orderDetailId)
        {
            var orderDetail = await _orderDetailRepository.GetByIdAsync(orderDetailId);
            if (orderDetail == null)
                return false;

            await _orderDetailRepository.RemoveAsync(orderDetail);
            return true;
        }
    }
}
