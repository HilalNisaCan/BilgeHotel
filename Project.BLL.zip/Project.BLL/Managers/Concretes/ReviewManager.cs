﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class ReviewManager:BaseManager<ReviewDto,Review>,IReviewManager
    {
        private readonly IReviewRepository _reviewRepository;
        private readonly IReservationRepository _reservationRepository;
        private readonly IRoomRepository _roomRepository;
        private readonly IMapper _mapper;

        public ReviewManager(IReviewRepository reviewRepository, IReservationRepository reservationRepository, IRoomRepository roomRepository, IMapper mapper)
            : base(reviewRepository, mapper)
        {
            _reviewRepository = reviewRepository;
            _reservationRepository = reservationRepository;
            _roomRepository = roomRepository;
            _mapper = mapper;
        }

        public async Task<int> AddReviewAsync(int reservationId, int userId, string comment, int rating)
        {
            var reservation = await _reservationRepository.GetByIdAsync(reservationId);
            if (reservation == null || reservation.UserId != userId) 
                throw new Exception("Geçersiz rezervasyon veya kullanıcı.");

            var review = new Review
            {
                ReservationId = reservationId,
                UserId = userId,
                RoomId = reservation.RoomId,
                Comment = comment,
                Rating = rating,
                CommentDate = DateTime.UtcNow,
                IsApproved = false
            };

            await _reviewRepository.AddAsync(review);
            return review.Id;
        }

        public async Task<bool> ApproveReviewAsync(int reviewId, bool isApproved)
        {
            var review = await _reviewRepository.GetByIdAsync(reviewId);
            if (review == null)
                return false;

            review.IsApproved = isApproved;
            await _reviewRepository.UpdateAsync(review);

            return true;
        }

        public async Task<bool> DeleteReviewAsync(int reviewId)
        {
            var review = await _reviewRepository.GetByIdAsync(reviewId);
            if (review == null)
                return false;

            await _reviewRepository.RemoveAsync(review);
            return true;
        }

        public async Task<List<ReviewDto>> GetReviewsByReservationAsync(int reservationId)
        {
            var reviews = await _reviewRepository.GetAllAsync(r => r.ReservationId == reservationId && r.IsApproved);
            return _mapper.Map<List<ReviewDto>>(reviews);
        }

        public async Task<List<ReviewDto>> GetReviewsByRoomAsync(int roomId)
        {
            var reviews = await _reviewRepository.GetAllAsync(r => r.RoomId == roomId && r.IsApproved);
            return _mapper.Map<List<ReviewDto>>(reviews);
        }

        public async Task<bool> UpdateReviewAsync(int reviewId, string comment, int rating)
        {
            var review = await _reviewRepository.GetByIdAsync(reviewId);
            if (review == null)
                return false;

            review.Comment = comment;
            review.Rating = rating;
            await _reviewRepository.UpdateAsync(review);

            return true;
        }

    }
}
