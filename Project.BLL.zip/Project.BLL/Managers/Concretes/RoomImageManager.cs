﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class RoomImageManager : BaseManager<RoomImageDto, RoomImage>, IRoomImageManager
    {
        private readonly IRoomImageRepository _roomImageRepository;
        private readonly IRoomRepository _roomRepository;
        private readonly IMapper _mapper;

        public RoomImageManager(IRoomImageRepository roomImageRepository, IRoomRepository roomRepository, IMapper mapper)
            : base(roomImageRepository, mapper)
        {
            _roomImageRepository = roomImageRepository;
            _roomRepository = roomRepository;
            _mapper = mapper;
        }

        public async Task<int> AddRoomImageAsync(int roomId, RoomImageDto roomImageDto)
        {
            var room = await _roomRepository.GetByIdAsync(roomId);
            if (room == null)
                throw new Exception("Oda bulunamadı.");

            var roomImage = _mapper.Map<RoomImage>(roomImageDto);
            roomImage.RoomId = roomId;

            await _roomImageRepository.AddAsync(roomImage);
            return roomImage.Id;
        }

        public async Task<bool> UpdateRoomImageAsync(int roomImageId, RoomImageDto roomImageDto)
        {
            var existingRoomImage = await _roomImageRepository.GetByIdAsync(roomImageId);
            if (existingRoomImage == null)
                return false;

            _mapper.Map(roomImageDto, existingRoomImage);
            await _roomImageRepository.UpdateAsync(existingRoomImage);

            return true;
        }

        public async Task<List<RoomImageDto>> GetImagesByRoomIdAsync(int roomId)
        {
            var roomImages = await _roomImageRepository.GetAllAsync(ri => ri.RoomId == roomId);
            return _mapper.Map<List<RoomImageDto>>(roomImages);
        }

        public async Task<bool> DeleteRoomImageAsync(int roomImageId)
        {
            var roomImage = await _roomImageRepository.GetByIdAsync(roomImageId);
            if (roomImage == null)
                return false;

            await _roomImageRepository.RemoveAsync(roomImage);
            return true;
        }
    }
}
