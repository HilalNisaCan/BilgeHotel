﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class GuestVisitLogManager : BaseManager<GuestVisitLogDto, GuestVisitLog>, IGuestVisitLogManager
    {
        private readonly IGuestVisitLogRepository _visitLogRepository;
        private readonly IRoomRepository _roomRepository;
        private readonly ICustomerRepository _customerRepository;
        private readonly IMapper _mapper;

        public GuestVisitLogManager(IGuestVisitLogRepository visitLogRepository, IRoomRepository roomRepository, ICustomerRepository customerRepository, IMapper mapper)
            : base(visitLogRepository, mapper)
        {
            _visitLogRepository = visitLogRepository;
            _roomRepository = roomRepository;
            _customerRepository = customerRepository;
            _mapper = mapper;
        }

        public async Task<bool> RegisterGuestEntryAsync(int customerId, int roomId)
        {
            var customer = await _customerRepository.GetByIdAsync(customerId);
            var room = await _roomRepository.GetByIdAsync(roomId);

            if (customer == null || room == null || room.Status != RoomStatus.Available)
                return false;

            // ✅ Aynı müşteri zaten giriş yaptı mı kontrol edelim
            var existingVisit = await _visitLogRepository.GetAllAsync(v => v.CustomerId == customerId && v.ExitDate == null);
            if (existingVisit.Any())
                throw new Exception("Bu müşteri zaten giriş yapmış.");

            // ✅ Son çıkış tarihini kontrol et
            var lastVisit = (await _visitLogRepository.GetAllAsync(v => v.CustomerId == customerId && v.ExitDate != null))
                            .OrderByDescending(v => v.ExitDate)
                            .FirstOrDefault();

            if (lastVisit != null && (DateTime.UtcNow - lastVisit.ExitDate.Value).TotalHours < 24)
                throw new Exception("Bu müşteri son çıkışından sonra 24 saat geçmeden tekrar giriş yapamaz.");

            var visitLog = new GuestVisitLog
            {
                CustomerId = customerId,
                RoomId = roomId,
                EntryDate = DateTime.UtcNow
            };

            await _visitLogRepository.AddAsync(visitLog);
            room.Status = RoomStatus.Occupied;
            await _roomRepository.UpdateAsync(room);

            return true;
        }


        public async Task<bool> RegisterGuestExitAsync(int customerId)
        {
            var visitLog = (await _visitLogRepository.GetAllAsync(v => v.CustomerId == customerId && v.ExitDate == null)).FirstOrDefault();

            if (visitLog == null)
                throw new Exception("Bu müşteri için aktif bir giriş kaydı bulunamadı.");

            visitLog.ExitDate = DateTime.UtcNow;
            await _visitLogRepository.UpdateAsync(visitLog);

            var room = await _roomRepository.GetByIdAsync(visitLog.RoomId);
            room.Status = RoomStatus.Cleaning;
            await _roomRepository.UpdateAsync(room);

            return true;
        }


        public async Task<List<GuestVisitLog>> GetGuestVisitHistoryAsync(int customerId)
        {
            return (await _visitLogRepository.GetAllAsync(v => v.CustomerId == customerId))
                    .OrderByDescending(v => v.EntryDate)
                    .ToList();
        }

    }
}
