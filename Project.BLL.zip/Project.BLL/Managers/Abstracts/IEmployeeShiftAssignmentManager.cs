﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IEmployeeShiftAssignmentManager : IManager<EmployeeShiftAssignmentDto, EmployeeShiftAssignment>
    {
        Task<int> AssignShiftAsync(int employeeId, int shiftId); // ✅ Çalışana vardiya ata
        Task<bool> RemoveShiftAssignmentAsync(int assignmentId); // ✅ Çalışanın vardiyasını kaldır
        Task<List<EmployeeShiftAssignmentDto>> GetEmployeeShiftsAsync(int employeeId); // ✅ Çalışanın tüm vardiyalarını getir
        Task<bool> ValidateShiftAssignmentAsync(int employeeId, int shiftId); // ✅ Vardiya atanabilir mi kontrol et
    }
}
