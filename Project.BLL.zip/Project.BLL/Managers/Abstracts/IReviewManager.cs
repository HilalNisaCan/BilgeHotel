﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IReviewManager : IManager<ReviewDto, Review>
    {
        Task<int> AddReviewAsync(int reservationId, int customerId, string comment, int rating); // ✅ Yeni müşteri yorumu ekle
        Task<bool> UpdateReviewAsync(int reviewId, string comment, int rating); // ✅ Yorumu güncelle
        Task<List<ReviewDto>> GetReviewsByRoomAsync(int roomId); // ✅ Belirli bir oda için yorumları getir
        Task<List<ReviewDto>> GetReviewsByReservationAsync(int reservationId); // ✅ Belirli bir rezervasyon için yorumları getir
        Task<bool> ApproveReviewAsync(int reviewId, bool isApproved); // ✅ Yorumu onayla veya reddet
        Task<bool> DeleteReviewAsync(int reviewId); // ✅ Yorumu sil
    }
}
