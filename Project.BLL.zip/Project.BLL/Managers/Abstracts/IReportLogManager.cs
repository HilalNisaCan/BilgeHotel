﻿using Project.BLL.DtoClasses;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IReportLogManager : IManager<ReportLogDto, ReportLog>
    {
        Task GenerateDailyCustomerReportAsync();  // ✅ Günlük müşteri raporu oluştur
        Task GenerateFinancialReportAsync();  // ✅ Finansal rapor oluştur
        Task<List<ReportLog>> GetReportsAsync(ReportType reportType);  // ✅ Belirli türdeki raporları getir
        Task<string> GenerateXmlReportAsync(ReportType reportType); // ✅ XML raporu oluştur
        Task<bool> SendXmlReportToAuthoritiesAsync(string xmlData, string endpointUrl); // ✅ XML verisini dinamik URL ile gönder
    }
}

