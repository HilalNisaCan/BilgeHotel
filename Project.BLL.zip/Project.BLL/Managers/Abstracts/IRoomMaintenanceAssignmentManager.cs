﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IRoomMaintenanceAssignmentManager : IManager<RoomMaintenanceAssignmentDto, RoomMaintenanceAssignment>
    {
        Task<int> AssignMaintenanceAsync(int roomId, int maintenanceId, int assignedEmployeeId); // ✅ Odaya bakım atama
        Task<bool> RemoveMaintenanceAssignmentAsync(int assignmentId); // ✅ Bakım atamasını kaldır
        Task<List<RoomMaintenanceAssignmentDto>> GetRoomMaintenanceAssignmentsAsync(int roomId); // ✅ Odanın bakım atamalarını getir
        Task<bool> CompleteMaintenanceAsync(int assignmentId); // ✅ Bakımı tamamlandı olarak işaretle
    }
}
