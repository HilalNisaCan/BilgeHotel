﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface ICustomerManager:IManager<CustomerDto,Customer>
    {
        Task<Customer> GetCustomerByIdAsync(int customerId); // ✅ Müşteri bilgilerini getirir
        Task<Customer> GetOrCreateCustomerAsync(int userId, string identityNumber, string firstName, string lastName, int birthYear); // ✅ Müşteri yoksa oluşturur
        Task<List<Reservation>> GetCustomerReservationsAsync(int customerId); // ✅ Müşterinin rezervasyon geçmişini getirir
        Task<decimal> GetLoyaltyPointsAsync(int customerId); // ✅ Sadakat Puanını Getirir
        Task UpdateLoyaltyPointsAsync(int customerId, decimal points); // ✅ Sadakat Puanını Günceller
        Task<bool> VerifyCustomerIdentityAsync(int customerId);
    }
}

