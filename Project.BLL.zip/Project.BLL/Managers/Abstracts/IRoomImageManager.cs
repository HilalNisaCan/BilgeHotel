﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IRoomImageManager : IManager<RoomImageDto, RoomImage>
    {
        Task<int> AddRoomImageAsync(int roomId, RoomImageDto roomImageDto); // ✅ Odaya görsel ekle
        Task<bool> UpdateRoomImageAsync(int roomImageId, RoomImageDto roomImageDto); // ✅ Görseli güncelle
        Task<List<RoomImageDto>> GetImagesByRoomIdAsync(int roomId); // ✅ Odaya ait tüm görselleri getir
        Task<bool> DeleteRoomImageAsync(int roomImageId); // ✅ Görseli sil
    }
}
