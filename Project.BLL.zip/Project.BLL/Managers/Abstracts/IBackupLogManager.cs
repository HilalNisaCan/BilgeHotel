﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IBackupLogManager : IManager<BackupLogDto, BackupLog>
    {
        Task<bool> BackupDatabaseAsync(int userId, string backupFolderPath); // ✅ Yetkilendirilmiş veritabanı yedekleme
        Task<bool> RestoreDatabaseAsync(int userId, string backupFilePath); // ✅ Yetkilendirilmiş veritabanı geri yükleme
        Task<List<BackupLog>> GetBackupHistoryAsync(); // ✅ Yedekleme geçmişini getir
        Task ScheduleAutomaticBackupAsync(); // ✅ Otomatik yedekleme planla
    }
}
