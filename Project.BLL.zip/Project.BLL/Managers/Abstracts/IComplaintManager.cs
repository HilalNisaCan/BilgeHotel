﻿using Project.BLL.DtoClasses;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IComplaintManager : IManager<ComplaintLogDto, ComplaintLog>
    {
        Task<int> AddComplaintAsync(int userId, string title, string description);  // Yeni şikayet ekler
        Task<List<ComplaintLog>> GetComplaintsAsync(ComplaintStatus status);  // Şikayetleri getirir
        Task UpdateComplaintStatusAsync(int complaintId, ComplaintStatus status);  // Şikayet durumunu günceller
        Task<List<ComplaintLog>> GetCustomerComplaintsAsync(int customerId); // ✅ Müşterinin geçmiş şikayetlerini getir
        Task<bool> RespondToComplaintAsync(int complaintId, string response); // ✅ Şikayete cevap ekler
        Task<bool> DeleteComplaintAsync(int complaintId); // ✅ Şikayeti siler
    }
}
