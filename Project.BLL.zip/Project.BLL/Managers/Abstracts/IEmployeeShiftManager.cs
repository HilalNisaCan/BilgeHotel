﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IEmployeeShiftManager:IManager<EmployeeShiftDto,EmployeeShift>
    {
        Task<bool> AssignShiftAsync(int employeeId, DateTime shiftStart, DateTime shiftEnd);
        Task<decimal> CalculateSalaryAsync(int employeeId);
        Task<decimal> CalculateOvertimeAsync(int employeeId); // ✅ Fazla mesai hesapla
        Task SetDayOffAsync(int employeeId, DateTime dayOffDate); // ✅ İzin günü ayarla
        Task<int> CalculateWeeklyHoursAsync(int employeeId); // ✅ Haftalık çalışma süresini hesapla
    }
}
