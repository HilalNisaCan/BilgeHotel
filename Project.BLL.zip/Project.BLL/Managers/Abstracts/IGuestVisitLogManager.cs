﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IGuestVisitLogManager : IManager<GuestVisitLogDto, GuestVisitLog>
    {
        Task<bool> RegisterGuestEntryAsync(int customerId, int roomId); // ✅ Müşteri giriş kaydı ekle
        Task<bool> RegisterGuestExitAsync(int customerId); // ✅ Müşteri çıkış kaydı ekle
        Task<List<GuestVisitLog>> GetGuestVisitHistoryAsync(int customerId); // ✅ Müşteri ziyaret geçmişini getir
    }
}
