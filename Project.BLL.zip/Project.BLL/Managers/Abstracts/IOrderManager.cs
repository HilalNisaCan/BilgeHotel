﻿using Project.BLL.DtoClasses;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IOrderManager : IManager<OrderDto, Order>
    {
        Task<int> AddOrderAsync(int reservationId, List<OrderDetailDto> orderDetails); // ✅ Yeni sipariş ekle
        Task<bool> UpdateOrderStatusAsync(int orderId, OrderStatus status); // ✅ Sipariş durumunu güncelle
        Task<List<OrderDto>> GetOrdersByReservationAsync(int reservationId); // ✅ Belirli bir rezervasyona ait siparişleri getir
        Task<bool> DeleteOrderAsync(int orderId); // ✅ Siparişi sil
    }
}
