﻿using Project.Entities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.DtoClasses
{
    public class EmployeeDto:BaseDto
    {
        public int? UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string PhoneNumber { get; set; }
        public string Address { get; set; }
        public string IdentityNumber { get; set; }
        public EmployeePosition Position { get; set; }
        public SalaryType SalaryType { get; set; }
        public TimeSpan ShiftStart { get; set; }
        public TimeSpan ShiftEnd { get; set; }
        public decimal HourlyWage { get; set; }
        public bool HasOvertime { get; set; }
        public int WeeklyWorkedHours { get; set; }
        public int TotalWorkedHours { get; set; }
        public bool IsActive { get; set; }
        public DateTime HireDate { get; set; }
    }
}
