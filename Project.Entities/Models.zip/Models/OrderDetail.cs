﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Entities.Models
{
    public class OrderDetail : BaseEntity
    {
        // Bu detay hangi siparişe ait?
        public int OrderId { get; set; }

        // Hangi ürün sipariş edildi?
        public int ProductId { get; set; }

        // Kaç adet sipariş edildi?
        public int Quantity { get; set; }

        // Sipariş sırasında ürünün birim fiyatı (değişebilir diye sabitlenmeli)
        public decimal UnitPrice { get; set; }

        //relational properties
        public virtual Order Order { get; set; } = null!; // Sipariş bilgisi
        public virtual Product Product { get; set; } = null!; // Ürün bilgisi
      

    }
}
