﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Entities.Enums
{
    public enum ReportStatus
    {
        Pending=0,     // Beklemede
        Success=1,     // Başarılı
        Failed=2      // Başarısız

    }
}
