﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Entities.Enums
{
    public enum SalaryType
    {
        Monthly=0,  // Yönetici maaşı için
        Hourly  =1  // Diğer çalışanlar için saatlik ödeme
    }
}
