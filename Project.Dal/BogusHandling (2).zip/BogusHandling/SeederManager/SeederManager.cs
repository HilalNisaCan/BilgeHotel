﻿using Microsoft.AspNetCore.Identity;
using Project.Dal.ContextClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Dal.BogusHandling.SeederManager
{/// <summary>
 /// Tüm sahte verilerin oluşturulmasını yöneten merkezi seeder sınıfıdır.
 /// Projedeki 13 seeder sınıfı burada sırayla tetiklenir.
 /// </summary>
    public static class SeederManager
    {
        public static async Task SeedAllAsync(MyContext context, UserManager<User> userManager)
        {
            Console.WriteLine("📦 Seed işlemi başlatıldı...\n");

            await EmployeeSeeder.SeedAsync(context);                     // 1️⃣ Çalışanlar (ilk!)
            AppUserSeeder appUserSeeder = new AppUserSeeder(userManager,context);
            await appUserSeeder.SeedAsync(context.Employees.ToList());  // 2️⃣ AppUser → sadece yöneticiler & resepsiyonistler için
            await CustomerSeeder.SeedAsync(context);                    // 3️⃣ Müşteriler (Customer rolündeki kullanıcılar için)
            await RoomSeeder.SeedAsync(context);                        // 4️⃣ Odalar
            await RoomImageSeeder.SeedAsync(context);                   // 5️⃣ Oda görselleri
            await RoomTypePriceSeeder.SeedAsync(context);               // 6️⃣ Oda fiyatları
            await EmployeeShiftSeeder.SeedAsync(context);               // 7️⃣ Vardiyalar (vardiya türleri ve tarihleri)
            await EmployeeShiftAssignmentSeeder.SeedAsync(context);     // 8️⃣ Vardiya atamaları
            await ReservationSeeder.SeedAsync(context);                 // 9️⃣ Rezervasyonlar (Customer ve Room bağlı)
            await PaymentSeeder.SeedAsync(context);                     // 🔟 Ödemeler (Reservation ve Customer bağlı)
            await ProductSeeder.SeedAsync(context);                     // 1️⃣1️⃣ Ürünler (Minibar, Bar, vb.)
            await OrderSeeder.SeedAsync(context);                       // 1️⃣2️⃣ Siparişler (Payment bağlı)
            await RoomCleaningScheduleSeeder.SeedAsync(context);        // 1️⃣3️⃣ Temizlik planı
            await RoomMaintenanceScheduleSeeder.SeedAsync(context);     // 1️⃣4️⃣ Bakım planı

            Console.WriteLine("\n✅ Tüm seed işlemleri tamamlandı!");
        }
    }


}   /*m bu sınıf projenin tüm sahte verilerini oluşturuyor.
Sadece SeedAllAsync() metodunu çağırmam yeterli.
Sıralı olarak 13 farklı tabloya mantıklı veriler ekleniyor.
Console logları sayesinde süreç profesyonelce takip edilebiliyor.”*/

