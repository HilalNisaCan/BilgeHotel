﻿using Bogus;
using Project.Dal.ContextClasses;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Dal.BogusHandling
{
    /// <summary>
    /// Sipariş (Order) verilerini sahte olarak üretip veritabanına ekleyen seeder sınıfıdır.
    /// Her müşteri için rastgele 3 sipariş üretilir.
    /// </summary>
    public static class OrderSeeder
    {
        /// <summary>
        /// Sipariş verilerini veritabanına ekler. Eğer Order tablosu boşsa çalışır.
        /// </summary>
        /// <param name="context">Veritabanı bağlamı</param>
        public static async Task SeedAsync(MyContext context)
        {
            Faker faker = new Faker("tr");

            if (!context.Orders.Any())
            {
                List<Order> orders = new List<Order>();

                List<Customer> customers = context.Customers.ToList();          // Tüm müşteriler
                List<Reservation> reservations = context.Reservations.ToList(); // Tüm rezervasyonlar

                // Her müşteri için 3 adet sahte sipariş oluştur
                foreach (Customer customer in customers)
                {
                    for (int i = 0; i < 3; i++)
                    {
                        Order order = new Order
                        {
                            // Kullanıcı ID (sisteme giriş yapan AppUser)
                            UserId = faker.Random.Int(1, 10),

                            // Rastgele bir rezervasyona bağlanır
                            ReservationId = faker.PickRandom(reservations).Id,

                            // Son 30 gün içinde oluşturulmuş bir sipariş tarihi
                            OrderDate = faker.Date.Between(DateTime.Now.AddDays(-30), DateTime.Now),

                            // Sipariş tipi (örnek: RoomService, Restaurant, Bar)
                            OrderType = faker.PickRandom<OrderType>(),

                            // Sipariş durumu
                            Status = faker.PickRandom<OrderStatus>(),

                            // Sipariş toplam tutarı
                            TotalAmount = Convert.ToDecimal(faker.Commerce.Price(100, 1000)),

                            CreatedDate = DateTime.Now,
                            ModifiedDate = null,
                            DeletedDate = null
                        };

                        orders.Add(order);
                    }
                }

                context.Orders.AddRange(orders);
                await context.SaveChangesAsync();
            }
        }
    }


    //“Hocam bu sınıf, her müşteri için rastgele 3 sipariş üretir. Sipariş tipi, durumu, tutarı gibi alanlar faker ile anlamlı biçimde doldurulur.
    //Bu yapı ileride ürün detayları veya sipariş analizleri için kolayca genişletilebilir.


    /*
     * Açıklamalar:
Bu seed, her müşteri için rastgele 3 sipariş ekler.

Sipariş türü, durumu, toplam miktar gibi veriler rastgele oluşturulur.

OrderType ve OrderStatus enum'ları kullanılacaktır.

*/
}
