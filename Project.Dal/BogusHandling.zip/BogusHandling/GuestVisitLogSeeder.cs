﻿using Bogus;
using Bogus.Extensions.UnitedStates;
using Project.Dal.ContextClasses;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Dal.BogusHandling
{
    /// <summary>
    /// Misafir ziyaret kayıtlarını sahte verilerle oluşturan seeder sınıfıdır.
    /// Sisteme giriş yapan misafirlerin bilgileri tutulur.
    /// </summary>
    public static class GuestVisitLogSeeder
    {
        /// <summary>
        /// Eğer GuestVisitLog tablosu boşsa 10 adet sahte ziyaret kaydı oluşturur.
        /// </summary>
        public static void Seed()
        {
            Faker faker = new Faker("tr");
            List<GuestVisitLog> visitLogs = new List<GuestVisitLog>();

            for (int i = 0; i < 10; i++)
            {
                // Giriş tarihi → geçmişte bir gün
                DateTime entryDate = faker.Date.Past(1);

                // Çıkış tarihi → giriş tarihinden 1–14 gün sonrası
                DateTime exitDate = entryDate.AddDays(faker.Random.Int(1, 14));

                GuestVisitLog guestVisit = new GuestVisitLog
                {
                    CustomerId = faker.Random.Int(1, 10),
                    RoomId = faker.Random.Int(1, 100), // Oda ID aralığı varsayım: 1–100

                    FirstName = faker.Name.FirstName(),
                    LastName = faker.Name.LastName(),

                    IdentityNumber = faker.Random.Replace("###########"), // 11 haneli TR kimlik no gibi

                    GuestNationality = faker.Address.Country(),
                    BirthDate = faker.Date.Past(30, DateTime.Today.AddYears(-18)), // 18 yaş üstü

                    EntryDate = entryDate,
                    ExitDate = exitDate,

                    Status = GuestVisitStatus.CheckedIn, // Konaklıyor olarak işaretli

                    CreatedDate = DateTime.Now,
                    ModifiedDate = null,
                    DeletedDate = null
                };

                visitLogs.Add(guestVisit);
            }

            using (MyContext context = new MyContext())
            {
                // Zaten veri varsa tekrarlama
                if (!context.GuestVisitLogs.Any())
                {
                    context.GuestVisitLogs.AddRange(visitLogs);
                    context.SaveChanges();
                }
            }
        }
    }
    /*
     * 
     * 
     * Bu sınıf, sisteme gelen misafir ziyaretlerinin log kaydını oluşturur.

     Kimlik numarası, doğum tarihi, giriş-çıkış gibi bilgiler Faker ile gerçekçi şekilde üretilir.

     Status enum'ı ile misafirin anlık durumu takip edilebilir (CheckedIn, CheckedOut, vs.).

     EntryDate < ExitDate garantilendi.

     BirthDate en az 18 yaş üstü olacak şekilde düzenlendi (yetişkin kontrolü).


    */



}

