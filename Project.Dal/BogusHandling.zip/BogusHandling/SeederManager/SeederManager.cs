﻿using Microsoft.AspNetCore.Identity;
using Project.Dal.ContextClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Dal.BogusHandling.SeederManager
{
    /// <summary>
    /// Tüm sahte verilerin oluşturulmasını yöneten merkezi seeder sınıfıdır.
    /// Projedeki 13 seeder sınıfı burada sırayla tetiklenir.
    /// </summary>
    public static class SeederManager
    {
        public static async Task SeedAllAsync(MyContext context, UserManager<User> userManager)
        {
            Console.WriteLine("📦 Seed işlemi başlatıldı...\n");

            // 1️ Çalışanları oluştur
            Console.WriteLine("👥 Employee verileri ekleniyor...");
            List<Employee> employees = EmployeeSeeder.GenerateEmployees();
            context.Employees.AddRange(employees);
            await context.SaveChangesAsync();

            // 2️ AppUser'ları oluştur (Yönetici + Resepsiyonist)
            Console.WriteLine("🔐 AppUser verileri ekleniyor...");
            AppUserSeeder appUserSeeder = new AppUserSeeder(userManager);
            await appUserSeeder.SeedAsync(employees);

            // 3 AppUser ID'leriyle Customer oluştur
            Console.WriteLine("👥 Customer verileri ekleniyor...");

            // Tüm UserId'leri al (AppUser tablosu)
            List<int> userIds = context.Users.Select(u => u.Id).ToList();

            // Daha önce Customer oluşturulmuş UserId'leri al
            List<int> existingCustomerUserIds = context.Customers.Select(c => c.UserId).ToList();

            // Yeni eklenmesi gereken müşterileri oluştur
            List<Customer> customers = CustomerSeeder.GenerateCustomers(userIds, existingCustomerUserIds);

            // Eğer eklenecek varsa ekle
            if (customers.Any())
            {
                context.Customers.AddRange(customers);
                await context.SaveChangesAsync();
                Console.WriteLine($"✅ {customers.Count} müşteri eklendi.");
            }
            else
            {
                Console.WriteLine("⚠️ Eklenmesi gereken yeni müşteri bulunamadı.");
            }

            // 4️ Room oluştur
            Console.WriteLine("🛏️ Room verileri ekleniyor...");
            List<Room> rooms = RoomSeeder.SeedRooms();
            context.Rooms.AddRange(rooms);
            await context.SaveChangesAsync();

            // 5️ Room Maintenance planları
            Console.WriteLine("🧰 Room Maintenance Schedule ekleniyor...");
            await RoomMaintenanceScheduleSeeder.SeedAsync(context);

            // 6️ Maintenance görev atamaları
            Console.WriteLine("👷‍♂️ Room Maintenance Assignments ekleniyor...");
            await RoomMaintenanceAssignmentSeeder.SeedAsync(context);

            // 7️ Room temizlik planları
            Console.WriteLine("🧽 Room Cleaning Schedule ekleniyor...");
            await RoomCleaningScheduleSeeder.SeedAsync(context);

            // 8️ Müşteri yorumları
            Console.WriteLine("⭐ Review verileri ekleniyor...");
            ReviewSeeder.Seed(context);

            // 9️ Rezervasyonlar
            Console.WriteLine("📆 Reservation verileri ekleniyor...");
            List<int> customerIds = context.Customers.Select(c => c.Id).ToList();
            List<int> roomIds = context.Rooms.Select(r => r.Id).ToList();
            List<int> paymentIds = new List<int>(); // Ödeme sistemi yoksa boş bırak
            List<Reservation> reservations = ReservationSeeder.GenerateReservations(10, customerIds, roomIds, paymentIds);
            context.Reservations.AddRange(reservations);
            await context.SaveChangesAsync();

            // 🔟 Ürünler
            Console.WriteLine("🛒 Product verileri ekleniyor...");
            List<Product> products = ProductSeeder.GenerateFakeProducts(20);
            context.Products.AddRange(products);
            await context.SaveChangesAsync();

            // 1️⃣1️⃣ Siparişler
            Console.WriteLine("🧾 Order verileri ekleniyor...");
            await OrderSeeder.SeedAsync(context);

            // 1️2️ Ziyaret kayıtları
            Console.WriteLine("🚪 Guest Visit Log ekleniyor...");
            GuestVisitLogSeeder.Seed();

            // 1️3️ Şikayet kayıtları
            Console.WriteLine("📣 Complaint Log ekleniyor...");
            ComplaintLogSeeder.Seed();

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n✅ Tüm seed işlemleri başarıyla tamamlandı.");
            Console.ResetColor();
        }
    }

    /*m bu sınıf projenin tüm sahte verilerini oluşturuyor.
Sadece SeedAllAsync() metodunu çağırmam yeterli.
Sıralı olarak 13 farklı tabloya mantıklı veriler ekleniyor.
Console logları sayesinde süreç profesyonelce takip edilebiliyor.”*/
}
