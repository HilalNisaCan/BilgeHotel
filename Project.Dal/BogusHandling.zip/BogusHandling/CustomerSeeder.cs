﻿using Bogus;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Dal.BogusHandling
{/// <summary>
 /// CustomerSeeder sınıfı, sahte müşteri (Customer) verisi üretmek için kullanılır.
 /// Bu sınıf, User tablosuna bağlı müşteri kayıtlarını oluşturur.
 /// Her kullanıcı (UserId) için yalnızca bir müşteri oluşturularak veri tekrarı engellenir.
 /// </summary>
    public static class CustomerSeeder
    {
        /// <summary>
        /// Kullanıcı ID listesine göre birebir eşleşen sahte müşteri kayıtları oluşturur.
        /// </summary>
        /// <param name="userIds">Kullanılabilir benzersiz User ID listesi</param>
        /// <returns>Customer listesi</returns>
        public static List<Customer> GenerateCustomers(List<int> userIds, List<int> existingCustomerUserIds)
        {
            Faker faker = new Faker("tr");
            List<Customer> customers = new List<Customer>();

            foreach (int userId in userIds)
            {
                // Aynı UserId'ye sahip bir müşteri varsa yeniden ekleme
                if (existingCustomerUserIds.Contains(userId))
                    continue;

                Customer customer = new Customer
                {
                    UserId = userId,
                    IdentityNumber = faker.Random.Replace("###########"), // 11 haneli TC no
                    LoyaltyPoints = faker.Random.Int(0, 10),
                    BillingDetails = faker.Address.FullAddress(),
                    IsIdentityVerified = faker.Random.Bool(),
                    NeedsIdentityCheck = faker.Random.Bool(),
                    CreatedDate = DateTime.Now,
                    Status = DataStatus.Inserted
                };

                customers.Add(customer);
            }

            return customers;
        }

          
        }
    }

    /*
    💡 Açıklamalar:
    UserId: Var olan User tablosundaki Id listesinden rastgele seçilir.

    IdentityNumber: Türkiye kimlik numarası formatına uygun (11 haneli) rastgele sayı.

    LoyaltyPoints: Müşteriye özel puan sistemi (0–10).

    IsIdentityVerified / NeedsIdentityCheck: Gerçek kimlik doğrulama işlemleri için kullanılabilir.

    DataStatus.Active: Bizim enum yapımıza uygun aktif durum bilgisi.

   bu sınıf, sisteme kayıtlı AppUser'lara bağlı olarak sahte müşteriler üretir.
  Kimlik numarası, fatura bilgisi, sadakat puanı gibi alanlar gerçekçi şekilde faker ile üretilmiştir.

    */


