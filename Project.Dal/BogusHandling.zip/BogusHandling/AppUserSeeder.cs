﻿using Bogus;
using Microsoft.AspNetCore.Identity;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Dal.BogusHandling
{
    /// <summary>
    /// Sisteme giriş yapacak kullanıcıları (yöneticiler ve resepsiyonistler) oluşturur.
    /// Console çıktıları ile hangi kullanıcıların başarıyla eklendiği ya da hata verdiği detaylı şekilde loglanır.
    /// </summary>
    public class AppUserSeeder
    {
        private readonly UserManager<User> _userManager;

        public AppUserSeeder(UserManager<User> userManager)
        {
            _userManager = userManager;
        }

        /// <summary>
        /// AppUser tablosuna yöneticiler ve resepsiyonistler için kullanıcılar eklenir.
        /// Console üzerinden profesyonel log çıktıları sağlanır.
        /// </summary>
        public async Task SeedAsync(List<Employee> employees)
        {
            if (_userManager.Users.Any()) return;

            List<User> createdUsers = new List<User>();

            // 🧑‍💼 Sabit yöneticiler
            List<(string FullName, string Username, string Email, UserRole Role)> adminList = new List<(string, string, string, UserRole)>
{
             // 👨‍💼 Selahattin Alkomut → İnsan Kaynakları Müdürü
            ("Selahattin Alkomut", "salkomut", "salkomut@bilgehotel.com", UserRole.HR),

            // 👨‍💼 Levent Sişarpsoy → Satış Müdürü
            ("Levent Sişarpsoy", "lsi_satis", "levent@bilgehotel.com", UserRole.Staff),

             // 👩‍💼 Gülay Aydınlık → Resepsiyon Şefi
             ("Gülay Aydınlık", "gaydinlik", "gulay@bilgehotel.com", UserRole.ReceptionChief),

             // 👨‍💻 Selahattin Karadibag → IT Sorumlusu
             ("Selahattin Karadibag", "skaradibag", "it@bilgehotel.com", UserRole.IT)
            };

            foreach ((string FullName, string Username, string Email, UserRole Role) admin in adminList)
            {
                User user = new User
                {
                    UserName = admin.Username,
                    Email = admin.Email,
                    Role = admin.Role,
                    IsActivated = true,
                    ActivationCode = Guid.NewGuid(),
                    CreatedDate = DateTime.Now,
                    Status = DataStatus.Inserted
                };

                IdentityResult result = await _userManager.CreateAsync(user, "123Pa$$word!");

                if (result.Succeeded)
                {
                    createdUsers.Add(user);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"✔️ [YÖNETİCİ EKLENDİ] → {admin.FullName} | Kullanıcı Adı: {admin.Username} | Rol: {admin.Role}");
                    Console.ResetColor();
                }
                else
                {
                    string errors = string.Join(", ", result.Errors.Select(e => e.Description));
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"❌ [YÖNETİCİ EKLENEMEDİ] → {admin.FullName} | Hata: {errors}");
                    Console.ResetColor();
                }
            }

            // 👩‍💼 Resepsiyonist çalışanlar için kullanıcı oluştur
            Faker faker = new Faker("tr");
            List<Employee> receptionists = employees.Where(e => e.Position == EmployeePosition.Receptionist).ToList();

            foreach (Employee receptionist in receptionists)
            {
                string username = faker.Internet.UserName(receptionist.FirstName, receptionist.LastName);
                string email = faker.Internet.Email(receptionist.FirstName, receptionist.LastName);

                User user = new User
                {
                    UserName = username,
                    Email = email,
                    Role = UserRole.Receptionist,
                    IsActivated = true,
                    ActivationCode = Guid.NewGuid(),
                    CreatedDate = DateTime.Now,
                    Status = DataStatus.Inserted
                };

                IdentityResult result = await _userManager.CreateAsync(user, "123Pa$$word!");

                if (result.Succeeded)
                {
                    createdUsers.Add(user);
                    receptionist.UserId = user.Id;

                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"👩‍💼 [RESEPSİYONİST EKLENDİ] → {receptionist.FirstName} {receptionist.LastName} | Kullanıcı Adı: {username}");
                    Console.ResetColor();
                }
                else
                {
                    string errors = string.Join(", ", result.Errors.Select(e => e.Description));
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"❌ [RESEPSİYONİST EKLENEMEDİ] → {receptionist.FirstName} {receptionist.LastName} | Hata: {errors}");
                    Console.ResetColor();
                }
            }
        }
    }
}

    // User sınıfı IdentityUser<int>'den miras alıyor. Bu nedenle kullanıcıları doğrudan context.Users.Add(user) şeklinde veritabanına atamıyoruz.

   //👉 Bunun yerine UserManager kullanıyoruz:

