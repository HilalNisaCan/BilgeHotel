﻿using Bogus;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Dal.BogusHandling
{

    /// <summary>
    /// RoomSeeder, Bilge Hotel’in odalarını kat ve tip dağılımına göre sahte verilerle doldurmak için kullanılır.
    /// Bu sınıf, otelin kat bazlı kurallarını birebir uygular.
    /// </summary>
    public static class RoomSeeder
    {
        /// <summary>
        /// Otelin tüm kat ve oda yapısına uygun şekilde sahte odaları üretir.
        /// </summary>
        /// <returns>List of Room</returns>
        public static List<Room> SeedRooms()
        {
            List<Room> rooms = new List<Room>();
            int roomNumber = 100;

            // KAT 1: 10 Tek kişilik, 10 Üç kişilik oda
            rooms.AddRange(CreateRooms(1, RoomType.Single, 10, ref roomNumber));
            rooms.AddRange(CreateRooms(1, RoomType.Triple, 10, ref roomNumber));

            // KAT 2: 10 Tek kişilik, 10 İki kişilik (çift yataklı)
            rooms.AddRange(CreateRooms(2, RoomType.Single, 10, ref roomNumber));
            rooms.AddRange(CreateRooms(2, RoomType.TwinBed, 10, ref roomNumber));

            // KAT 3: 10 İki kişilik (tek yataklı), 10 Üç kişilik
            rooms.AddRange(CreateRooms(3, RoomType.DoubleBed, 10, ref roomNumber));
            rooms.AddRange(CreateRooms(3, RoomType.Triple, 10, ref roomNumber));

            // KAT 4: 10 İki kişilik (tek yataklı), 6 Dört kişilik, 1 Kral Dairesi
            rooms.AddRange(CreateRooms(4, RoomType.DoubleBed, 10, ref roomNumber));
            rooms.AddRange(CreateRooms(4, RoomType.Quad, 6, ref roomNumber));
            rooms.AddRange(CreateRooms(4, RoomType.KingSuite, 1, ref roomNumber));

            return rooms;
        }

        /// <summary>
        /// Verilen parametrelere göre oda listesi oluşturur.
        /// Kat numarasına göre balkon, oda tipine göre minibar gibi kurallar uygulanır.
        /// </summary>
        private static List<Room> CreateRooms(int floor, RoomType roomType, int count, ref int roomNumber)
        {
            List<Room> list = new List<Room>();
            Random random = new Random();

            for (int i = 0; i < count; i++)
            {
                Room room = new Room
                {
                    RoomNumber = roomNumber.ToString(),
                    FloorNumber = floor,
                    RoomType = roomType,
                    Capacity = GetCapacity(roomType),
                    HasBalcony = floor >= 3,                     // 3. ve 4. katta balkon var
                    HasMinibar = roomType != RoomType.Single,    // Tek kişilik hariç minibar var
                    HasAirConditioning = true,
                    HasTV = true,
                    HasHairDryer = true,
                    HasWirelessInternet = true,
                    PricePerNight = (decimal)(random.NextDouble() * (3000 - 500) + 500),
                    IsCleaned = random.Next(0, 2) == 0,
                    Status = RoomStatus.Available,
                    CreatedDate = DateTime.Now,
                    ModifiedDate = null,
                    DeletedDate = null
                };

                list.Add(room);
                roomNumber++;
            }

            return list;
        }

        /// <summary>
        /// Oda tipine göre kaç kişi kalabileceğini döndürür.
        /// </summary>
        private static int GetCapacity(RoomType type)
        {
            return type switch
            {
                RoomType.Single => 1,
                RoomType.DoubleBed => 2,
                RoomType.TwinBed => 2,
                RoomType.Triple => 3,
                RoomType.Quad => 4,
                RoomType.KingSuite => 5,
                _ => 1
            };
        }
    }
}