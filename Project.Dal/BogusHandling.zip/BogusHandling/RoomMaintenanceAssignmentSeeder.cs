﻿using Bogus;
using Project.Dal.ContextClasses;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Dal.BogusHandling
{
    /// <summary>
    /// Oda bakım görevlerine sahte olarak çalışan atamak için kullanılan seeder sınıfıdır.
    /// RoomMaintenanceAssignment tablosunu rastgele ama anlamlı verilerle doldurur.
    /// </summary>
    public static class RoomMaintenanceAssignmentSeeder
    {
        /// <summary>
        /// Bakım görevlerine rastgele çalışanlar atar. Eğer daha önce atama yapılmamışsa çalışır.
        /// </summary>
        /// <param name="context">Veritabanı bağlamı</param>
        public static async Task SeedAsync(MyContext context)
        {
            // Daha önce veri varsa seedleme yapma
            if (context.RoomMaintenanceAssignments.Any())
                return;

            Faker faker = new Faker("tr");
            List<RoomMaintenanceAssignment> assignments = new List<RoomMaintenanceAssignment>();

            // Gerekli veriler toplanıyor
            List<RoomMaintenance> maintenances = context.RoomMaintenances.ToList(); // Mevcut bakım planları
            List<Employee> employees = context.Employees.ToList();                  // Tüm çalışanlar

            foreach (RoomMaintenance maintenance in maintenances)
            {
                // Her bakım için 1 ila 2 çalışan atanır
                List<Employee> assignedEmployees = faker.PickRandom(employees, faker.Random.Int(1, 2)).ToList();

                foreach (Employee employee in assignedEmployees)
                {
                    DateTime assignedDate = maintenance.ScheduledDate.AddDays(faker.Random.Int(-2, 0));

                    RoomMaintenanceAssignment assignment = new RoomMaintenanceAssignment
                    {
                        RoomId = maintenance.RoomId,
                        RoomMaintenanceId = maintenance.Id,
                        EmployeeId = employee.Id,
                        AssignedDate = assignedDate,
                        CompletedDate = assignedDate.AddHours(faker.Random.Int(1, 4)), // 1-4 saat içinde tamamlanmış kabul edilir
                        MaintenanceStatus = faker.PickRandom<MaintenanceStatus>(),
                        Description = faker.Lorem.Sentence(),
                        CreatedDate = DateTime.Now,
                        ModifiedDate = DateTime.Now,
                        DeletedDate = null
                    };

                    assignments.Add(assignment);
                }
            }

            // Üretilen bakım atamaları veritabanına eklenir
            context.RoomMaintenanceAssignments.AddRange(assignments);
            await context.SaveChangesAsync();
        }
    }



    /*
     * 
     * Her RoomMaintenance için 1–2 rastgele çalışan atanır.

Atama tarihi, planlanan bakım tarihinden birkaç gün öncesine ayarlanır.

Durum (başladı, tamamlandı vs.) rastgele seçilir.

Faker ile açıklamalar üretilir.

Her görev mantıklı zaman aralığında tamamlanmış kabul edilir.

Zaten görev ataması yapılmışsa SeedAsync() çalışmaz (idempotent yapı).
     *
     * 
     */
}

