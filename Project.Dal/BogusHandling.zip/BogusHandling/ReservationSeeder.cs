﻿using Bogus;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Project.Dal.BogusHandling
{

    /// <summary>
    /// ReservationSeeder sınıfı, sahte rezervasyon verileri oluşturmak için kullanılır.
    /// Müşteri, oda ve ödeme ID’lerine dayalı olarak rastgele ama mantıklı rezervasyonlar üretir.
    /// </summary>
    public static class ReservationSeeder
    {
        /// <summary>
        /// Belirtilen sayıda sahte rezervasyon üretir.
        /// </summary>
        /// <param name="count">Kaç adet rezervasyon üretileceği</param>
        /// <param name="customerIds">Geçerli müşteri ID’leri</param>
        /// <param name="roomIds">Geçerli oda ID’leri</param>
        /// <param name="paymentIds">Geçerli ödeme ID’leri</param>
        /// <returns>Üretilen rezervasyon listesi</returns>
        public static List<Reservation> GenerateReservations(int count, List<int> customerIds, List<int> roomIds, List<int> paymentIds)
        {
            Faker faker = new Faker("tr");
            List<Reservation> reservations = new List<Reservation>();

            for (int i = 0; i < count; i++)
            {
                // Başlangıç tarihi: bugünden sonraki bir tarih
                DateTime startDate = faker.Date.Future(1);

                // Bitiş tarihi: başlangıçtan 1–14 gün sonrası
                DateTime endDate = startDate.AddDays(faker.Random.Int(1, 14));

                Reservation reservation = new Reservation
                {
                    // Müşteri, oda ve ödeme ID’leri rastgele seçilir
                    CustomerId = faker.PickRandom(customerIds),
                    RoomId = faker.PickRandom(roomIds),
                    PaymentId = faker.PickRandom(paymentIds),

                    // Rezervasyon oluşturulma tarihi (geçmiş bir tarih)
                    ReservationDate = faker.Date.Past(1),

                    StartDate = startDate,
                    EndDate = endDate,

                    // Sabit giriş saati
                    CheckInTime = new TimeSpan(14, 0, 0),

                    // 1–5 kişi konaklayabilir
                    NumberOfGuests = faker.Random.Int(1, 5),

                    // Rastgele bir paket (örnek: Full, Half, etc.)
                    Package = faker.PickRandom<ReservationPackage>(),

                    // Fiyat ve indirim
                    TotalPrice = faker.Finance.Amount(1000, 5000),
                    DiscountRate = faker.Random.Decimal(0, 50),

                    // Para birimi
                    CurrencyCode = faker.PickRandom<Currency>().ToString(),

                    // Rezervasyon durumu: Onaylı
                    Status = ReservationStatus.Confirmed,

                    CreatedDate = DateTime.Now,
                    ModifiedDate = DateTime.Now,
                    DeletedDate = null
                };

                reservations.Add(reservation);
            }

            return reservations;
        }
    }


    /*  Tüm rezervasyonlar müşteri, oda ve ödeme tablolarına bağlı. (FK test senaryosu)

  Check-in tarihi gelecekte, konaklama süresi 1–14 gün arası olarak belirleniyor.

  Saat sabit: 14:00 (dökümantasyonla uyumlu)
      Fiyatlar ve indirim oranları gerçekçi aralıklarda.

  CurrencyCode, sistemde döviz bazlı işlem varsa buna hazır olacak şekilde bırakıldı.

  Yorumlar sayesinde her alanın ne işe yaradığını göstermek kolay.*/


}
