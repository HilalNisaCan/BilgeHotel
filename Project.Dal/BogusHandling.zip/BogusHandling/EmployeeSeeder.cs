﻿using Bogus;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Dal.BogusHandling
{
    /// <summary>
    /// Çalışan (Employee) verilerini sahte ve özel örneklerle oluşturan seeder sınıfıdır.
    /// Hem özel yöneticiler hem de farklı pozisyonlarda sahte çalışanlar üretilir.
    /// </summary>
    public static class EmployeeSeeder
    {
        /// <summary>
        /// Özel yöneticilerle birlikte sahte çalışanları içeren bir liste döner.
        /// </summary>
        public static List<Employee> GenerateEmployees()
        {
            List<Employee> employees = new List<Employee>();

            // 🔒 Sabit yöneticiler (elle eklenmiş)
            employees.Add(new Employee
            {
                FirstName = "Selahattin",
                LastName = "Alkomut",
                PhoneNumber = "05001112233",
                Address = "İstanbul",
                IdentityNumber = "12345678901",
                Position = EmployeePosition.HumanResourcesManager,
                SalaryType = SalaryType.Monthly,
                HourlyWage = 150,
                ShiftStart = new TimeSpan(8, 0, 0),
                ShiftEnd = new TimeSpan(17, 0, 0),
                HasOvertime = true,
                WeeklyWorkedHours = 45,
                TotalWorkedHours = 1800,
                IsActive = true,
                HireDate = DateTime.Now.AddYears(-2),
                CreatedDate = DateTime.Now,
                Status = DataStatus.Inserted
            });

            employees.Add(new Employee
            {
                FirstName = "Levent",
                LastName = "Sişarpsoy",
                PhoneNumber = "05003334455",
                Address = "Ankara",
                IdentityNumber = "12345678902",
                Position = EmployeePosition.SalesManager,
                SalaryType = SalaryType.Monthly,
                HourlyWage = 145,
                ShiftStart = new TimeSpan(9, 0, 0),
                ShiftEnd = new TimeSpan(18, 0, 0),
                HasOvertime = false,
                WeeklyWorkedHours = 40,
                TotalWorkedHours = 1600,
                IsActive = true,
                HireDate = DateTime.Now.AddYears(-1),
                CreatedDate = DateTime.Now,
                Status = DataStatus.Inserted
            });

            employees.Add(new Employee
            {
                FirstName = "Gülay",
                LastName = "Aydınlık",
                PhoneNumber = "05005556677",
                Address = "İzmir",
                IdentityNumber = "12345678903",
                Position = EmployeePosition.ReceptionChief,
                SalaryType = SalaryType.Monthly,
                HourlyWage = 120,
                ShiftStart = new TimeSpan(7, 0, 0),
                ShiftEnd = new TimeSpan(15, 0, 0),
                HasOvertime = true,
                WeeklyWorkedHours = 44,
                TotalWorkedHours = 1700,
                IsActive = true,
                HireDate = DateTime.Now.AddYears(-3),
                CreatedDate = DateTime.Now,
                Status = DataStatus.Inserted
            });

            employees.Add(new Employee
            {
                FirstName = "Selahattin",
                LastName = "Karadibag",
                PhoneNumber = "05009998877",
                Address = "Bursa",
                IdentityNumber = "12345678904",
                Position = EmployeePosition.ITSpecialist,
                SalaryType = SalaryType.Monthly,
                HourlyWage = 160,
                ShiftStart = new TimeSpan(10, 0, 0),
                ShiftEnd = new TimeSpan(19, 0, 0),
                HasOvertime = true,
                WeeklyWorkedHours = 46,
                TotalWorkedHours = 1850,
                IsActive = true,
                HireDate = DateTime.Now.AddYears(-1),
                CreatedDate = DateTime.Now,
                Status = DataStatus.Inserted
            });

            // 🧪 Faker ile sahte çalışanlar oluşturuluyor (44 kişi)
            Faker faker = new Faker("tr");
            employees.AddRange(FakeEmployees(faker, EmployeePosition.Receptionist, 7));
            employees.AddRange(FakeEmployees(faker, EmployeePosition.Cleaner, 11));
            employees.AddRange(FakeEmployees(faker, EmployeePosition.Chef, 11));
            employees.AddRange(FakeEmployees(faker, EmployeePosition.Waiter, 13));
            employees.AddRange(FakeEmployees(faker, EmployeePosition.Electrician, 1));
            employees.AddRange(FakeEmployees(faker, EmployeePosition.ITSpecialist, 1));

            return employees;
        }

        /// <summary>
        /// Belirtilen pozisyonda ve sayıda sahte çalışan üretir.
        /// </summary>
        private static List<Employee> FakeEmployees(Faker faker, EmployeePosition position, int count)
        {
            Faker<Employee> employeeFaker = new Faker<Employee>("tr")
                .RuleFor(e => e.FirstName, f => f.Name.FirstName())
                .RuleFor(e => e.LastName, f => f.Name.LastName())
                .RuleFor(e => e.PhoneNumber, f => f.Phone.PhoneNumber("05#########"))
                .RuleFor(e => e.Address, f => f.Address.FullAddress())
                .RuleFor(e => e.IdentityNumber, f => f.Random.ReplaceNumbers("###########"))
                .RuleFor(e => e.Position, position)
                .RuleFor(e => e.SalaryType, f => f.PickRandom<SalaryType>())
                .RuleFor(e => e.HourlyWage, f => f.Random.Decimal(80, 200))
                .RuleFor(e => e.ShiftStart, new TimeSpan(8, 0, 0))
                .RuleFor(e => e.ShiftEnd, new TimeSpan(17, 0, 0))
                .RuleFor(e => e.HasOvertime, f => f.Random.Bool())
                .RuleFor(e => e.WeeklyWorkedHours, f => f.Random.Int(35, 50))
                .RuleFor(e => e.TotalWorkedHours, f => f.Random.Int(500, 2000))
                .RuleFor(e => e.IsActive, true)
                .RuleFor(e => e.HireDate, f => f.Date.Past(3))
                .RuleFor(e => e.CreatedDate, DateTime.Now)
                .RuleFor(e => e.Status, DataStatus.Inserted);

            return employeeFaker.Generate(count);
        }
    }


    /*“Yöneticiler tek tek elle girildi, çünkü sistemde özel rolleri var. Diğer çalışanlar ise pozisyon bazlı sayılarla faker ile üretildi.”

“Çalışanlar için pozisyon, vardiya saatleri, maaş türü, mesai bilgileri gibi tüm alanlar sahte ama gerçekçi şekilde doldu.”

“Yönetici değişmez ama garson sayısı arttırılabilir — bu yüzden bu yapı esnek tutuldu.”

*/
}
