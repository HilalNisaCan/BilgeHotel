﻿using Bogus;
using Project.Dal.ContextClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Dal.BogusHandling
{
    /// <summary>
    /// Sahte müşteri yorumları üretmek için kullanılan ReviewSeeder sınıfıdır.
    /// Yorumlar, kullanıcı, rezervasyon ve oda ilişkilerini kapsayacak şekilde oluşturulur.
    /// </summary>
    public static class ReviewSeeder
    {
        /// <summary>
        /// Eğer sistemde daha önce yorum yoksa, 10 adet sahte yorum oluşturur ve veritabanına ekler.
        /// </summary>
        public static void Seed(MyContext context)
        {
            Faker faker = new Faker("tr");

            // Sahte yorum listesi
            List<Review> reviews = new List<Review>();

            for (int i = 0; i < 10; i++)
            {
                Review review = new Review
                {
                    // Rastgele kullanıcı, rezervasyon ve oda ID'leri
                    UserId = faker.Random.Int(1, 10),
                    ReservationId = faker.Random.Int(1, 10),
                    RoomId = faker.Random.Int(1, 10),

                    // 1 ile 5 arasında puanlama
                    Rating = faker.Random.Int(1, 5),

                    // Yoruma ait metin
                    Comment = faker.Lorem.Sentence(),

                    // Geçmişe ait rastgele yorum tarihi
                    CommentDate = faker.Date.Past(),

                    // Yorum onaylı mı?
                    IsApproved = faker.Random.Bool(),

                    // Yorum anonim mi?
                    IsAnonymous = faker.Random.Bool(),

                    // Tarih bilgileri
                    CreatedDate = DateTime.Now,
                    ModifiedDate = null,
                    DeletedDate = null
                };

                reviews.Add(review);
            }

            context.Reviews.AddRange(reviews);
            context.SaveChanges();
        }
    }


    /*
     * 
     * Faker ile rastgele Rating, Comment, CommentDate, IsApproved, IsAnonymous üretildi.

     Veritabanı boşsa sadece o zaman veri ekleniyor. (İdempotent yapı ✅)

     10 sahte yorum, sistemin test senaryolarında kullanılabilir.

     Kullanıcı, rezervasyon ve oda ID'leri rastgele verildi ama gerçek projede foreign key'lere uygun atanmalı (test verisiyle senkronize olması şart).
     * 
     * 
     * 
     * 
     * 
     * */
}