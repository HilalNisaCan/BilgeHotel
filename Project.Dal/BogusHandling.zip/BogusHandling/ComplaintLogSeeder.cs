﻿using Bogus;
using Project.Dal.ContextClasses;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Dal.BogusHandling
{
    /// <summary>
    /// ComplaintLogSeeder, sistemdeki müşteri şikayetlerini temsil eden sahte kayıtları oluşturur.
    /// Şikayet durumu, çözülme durumu ve sistem yanıtları gibi alanlar sahte şekilde doldurulur.
    /// </summary>
    public static class ComplaintLogSeeder
    {
        /// <summary>
        /// Eğer ComplaintLog tablosu boşsa, 10 adet sahte şikayet kaydı oluşturur.
        /// </summary>
        public static void Seed()
        {
            Faker faker = new Faker("tr");
            List<ComplaintLog> complaints = new List<ComplaintLog>();

            for (int i = 0; i < 10; i++)
            {
                ComplaintLog complaint = new ComplaintLog
                {
                    CustomerId = faker.Random.Int(1, 10),                     // Rastgele müşteri ID'si
                    Subject = faker.Lorem.Sentence(3),                       // Şikayet başlığı
                    Description = faker.Lorem.Paragraph(),                   // Açıklama
                    Status = faker.PickRandom<ComplaintStatus>(),            // Durumu
                    SubmittedDate = faker.Date.Past(),                       // Şikayetin yapıldığı tarih
                    Response = faker.Lorem.Sentence(),                       // Sistem cevabı
                    IsResolved = faker.Random.Bool(),                        // Çözülme durumu
                    CreatedDate = DateTime.Now,
                    ModifiedDate = null,
                    DeletedDate = null
                };

                complaints.Add(complaint);
            }

            using (MyContext context = new MyContext())
            {
                if (!context.ComplaintLogs.Any())
                {
                    context.ComplaintLogs.AddRange(complaints);
                    context.SaveChanges();
                }
            }
        }
    }

    /*
     * bu sınıf müşteri şikayetlerini simüle ediyor. Şikayet başlığı, açıklaması, durumu ve sistem cevabı faker ile oluşturuluyor.
     * Şikayet kayıtları ComplaintStatus enum'ına göre çeşitlendirildi.
     * 
     * Her şikayet, sahte ama anlamlı veri ile dolduruldu (konu, açıklama, yanıt).

Status alanı ComplaintStatus enum’undan rastgele seçildi.

IsResolved = çözülüp çözülmediği bilgisi (analiz için kullanılabilir).

SubmittedDate geçmişe dönük bir tarih olarak ayarlandı.

CustomerId sahte müşterilere referans veriyor.
    */
}
