﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IExtraExpenseManager : IManager<ExtraExpenseDto, ExtraExpense>
    {
        Task<int> AddExtraExpenseAsync(int reservationId, decimal unitPrice, string description); // ✅ Yeni ekstra harcama ekle
        Task<bool> UpdateExtraExpenseAsync(int expenseId, decimal unitPrice, string description); // ✅ Harcama güncelle
        Task<List<ExtraExpenseDto>> GetExtraExpensesByReservationAsync(int reservationId); // ✅ Belirli bir rezervasyona ait harcamaları getir
        Task<bool> DeleteExtraExpenseAsync(int expenseId); // ✅ Ekstra harcamayı sil
    }
}
