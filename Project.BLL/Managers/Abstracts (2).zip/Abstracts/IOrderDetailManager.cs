﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IOrderDetailManager : IManager<OrderDetailDto, OrderDetail>
    {
        Task<int> AddOrderDetailAsync(int orderId, OrderDetailDto orderDetailDto); // ✅ Siparişe ürün ekle
        Task<bool> UpdateOrderDetailAsync(int orderDetailId, OrderDetailDto orderDetailDto); // ✅ Sipariş ürününü güncelle
        Task<List<OrderDetailDto>> GetOrderDetailsByOrderIdAsync(int orderId); // ✅ Siparişe ait tüm ürünleri getir
        Task<bool> DeleteOrderDetailAsync(int orderDetailId); // ✅ Siparişten bir ürünü kaldır
    }
}
