﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IRoomCleaningScheduleManager : IManager<RoomCleaningScheduleDto, RoomCleaningSchedule>
    {
        Task<int> ScheduleRoomCleaningAsync(int roomId, DateTime cleaningDate); // ✅ Oda için temizlik planı oluştur
        Task<bool> MarkCleaningAsCompletedAsync(int cleaningScheduleId); // ✅ Temizlik işlemini tamamlandı olarak işaretle
        Task<List<RoomCleaningScheduleDto>> GetScheduledCleaningsAsync(DateTime date); // ✅ Belirli bir tarihteki temizlik programlarını getir
    }
}
