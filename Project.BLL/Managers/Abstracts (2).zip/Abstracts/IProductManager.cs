﻿using Project.BLL.DtoClasses;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IProductManager : IManager<ProductDto, Product>
    {
        Task<int> AddProductAsync(ProductDto productDto); // ✅ Yeni ürün ekle
        Task<bool> UpdateProductAsync(int productId, ProductDto productDto); // ✅ Ürünü güncelle
        Task<ProductDto> GetProductByIdAsync(int productId); // ✅ Belirli bir ürünü getir
        Task<List<ProductDto>> GetAllProductsAsync(); // ✅ Tüm ürünleri listele
        Task<List<ProductDto>> GetProductsByCategoryAsync(ProductCategory category); // ✅ Kategori bazlı ürün listele
        Task<bool> DeleteProductAsync(int productId); // ✅ Ürünü sil
    }
}
