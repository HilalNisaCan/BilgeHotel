﻿using Project.BLL.DtoClasses;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IUserManager:IManager<UserDto,User>
    {
        Task<int> RegisterUserAsync(UserDto userDto, string password); // ✅ Yeni kullanıcı kaydı oluştur
        Task<UserDto> AuthenticateUserAsync(string email, string password); // ✅ Kullanıcı giriş yapma ve doğrulama
        Task<bool> UpdateUserAsync(int userId, UserDto userDto); // ✅ Kullanıcı bilgilerini güncelle
        Task<bool> ChangeUserStatusAsync(int userId, bool isActive); // ✅ Kullanıcıyı aktif/pasif yap
        Task<bool> AssignRoleAsync(int userId, UserRole role); // ✅ Kullanıcı rolünü güncelle
    }
}
