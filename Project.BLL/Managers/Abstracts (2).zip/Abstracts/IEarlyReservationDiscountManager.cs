﻿using Project.BLL.DtoClasses;
using Project.BLL.Managers.Concretes;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IEarlyReservationDiscountManager:IManager<EarlyReservationDiscountDto,EarlyReservationDiscount>
    {
        Task<decimal> CalculateDiscountAsync(int customerId, DateTime reservationDate, DateTime checkInDate, decimal basePrice, ReservationPackage package); // ✅ İndirim hesapla (Müşteri sadakat puanı ve kampanyalar dahil)
        Task<bool> ApplyDiscountToReservationAsync(int reservationId); // ✅ İndirimi rezervasyona uygula
    }
}
