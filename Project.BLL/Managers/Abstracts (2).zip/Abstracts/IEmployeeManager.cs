﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IEmployeeManager : IManager<EmployeeDto, Employee>
    {
        Task<int> AddEmployeeAsync(EmployeeDto employeeDto); // ✅ Yeni çalışan ekle
        Task<bool> UpdateEmployeeAsync(int employeeId, EmployeeDto employeeDto); // ✅ Çalışan bilgilerini güncelle
        Task<EmployeeDto> GetEmployeeByIdAsync(int employeeId); // ✅ Belirli bir çalışanı getir
        Task<List<EmployeeDto>> GetAllEmployeesAsync(); // ✅ Tüm çalışanları listele
        Task<bool> DeleteEmployeeAsync(int employeeId); // ✅ Çalışanı sil
        Task<decimal> GetManagerSalaryAsync(int employeeId);
        Task AssignShiftAsync(int employeeId, int shiftId, DateTime assignmentDate);
        Task<decimal> CalculateSalaryAsync(int employeeId); // 👈 saatlik maaş
        Task TrackOvertimeAsync(int employeeId, int extraHours); // 👈 ek mesai gir
    }
}
