﻿using Project.BLL.DtoClasses;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IExchangeRateManager : IManager<ExchangeRateDto, ExchangeRate>
    {
        Task UpdateExchangeRateAsync(Currency from, Currency to, decimal rate); // ✅ Döviz kuru güncelle
        Task<decimal> ConvertCurrencyAsync(decimal amount, Currency from, Currency to); // ✅ Para birimini çevir
        Task FetchLatestExchangeRatesAsync(); // ✅ API'den en güncel döviz kurlarını al
    }
}
