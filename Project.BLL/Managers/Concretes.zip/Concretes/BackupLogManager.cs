﻿using AutoMapper;
using Microsoft.Data.SqlClient;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class BackupLogManager : BaseManager<BackupLogDto, BackupLog>, IBackupLogManager
    {
        private readonly string _connectionString;
        private readonly IRepository<BackupLog> _backupRepository;
        private readonly IMapper _mapper;
        public BackupLogManager(IBackUpRepository backupRepository, string connectionString, IMapper mapper) : base(backupRepository, mapper)
        {
            _connectionString = connectionString;
            _backupRepository = backupRepository;
        }

        // 1️⃣ Veritabanı Yedekleme
        public async Task<bool> BackupDatabaseAsync(string backupFolderPath)
        {
            string backupFilePath = Path.Combine(backupFolderPath, $"Backup_{DateTime.UtcNow:yyyyMMddHHmmss}.bak");

            string query = $"BACKUP DATABASE BilgeHotel TO DISK = '{backupFilePath}'";

            try
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    await conn.OpenAsync();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        await cmd.ExecuteNonQueryAsync();
                    }
                }

                var backupLog = new BackupLog
                {
                    FilePath = backupFilePath,
                    CreatedDate = DateTime.UtcNow,
                    Status = BackupStatus.Success
                };

                await _backupRepository.AddAsync(backupLog);
                return true;
            }
            catch
            {
                var backupLog = new BackupLog
                {
                    FilePath = backupFilePath,
                    CreatedDate = DateTime.UtcNow,
                    Status = BackupStatus.Failed
                };

                await _backupRepository.AddAsync(backupLog);
                return false;
            }
        }


        // 3️⃣ Yedekleme Geçmişini Getir
        public async Task<List<BackupLog>> GetBackupHistoryAsync()
        {
            return (await _backupRepository.GetAllAsync()).ToList();
        }

        // 2️⃣ Veritabanı Geri Yükleme
        public async Task<bool> RestoreDatabaseAsync(string backupFilePath)
        {
            string query = $"RESTORE DATABASE BilgeHotel FROM DISK = '{backupFilePath}' WITH REPLACE";

            try
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    await conn.OpenAsync();
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        await cmd.ExecuteNonQueryAsync();
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
