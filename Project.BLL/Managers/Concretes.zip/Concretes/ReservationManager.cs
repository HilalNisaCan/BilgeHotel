﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class ReservationManager : BaseManager<ReservationDto, Reservation>, IReservationManager
    {
        private readonly IRepository<Reservation> _reservationRepository;
        private readonly IRepository<Customer> _customerRepository;
        private readonly IRepository<Room> _roomRepository;
        private readonly IEarlyReservationDiscountManager _discountService; // ✅ Erken rezervasyon indirimi için
        private readonly IMapper _mapper;

       
        public ReservationManager(IReservationRepository reservationRepo, IRepository<Customer> customerRepo, IRepository<Room> roomRepo, IMapper mapper, IEarlyReservationDiscountManager discountService) : base(reservationRepo, mapper)
        {
            _reservationRepository = reservationRepo;
            _customerRepository = customerRepo;
            _roomRepository = roomRepo;
            _mapper = mapper;
            _discountService = discountService;
        }

        public async Task<bool> MakeReservationAsync(int customerId, int roomId, DateTime startDate, int duration, ReservationPackage package)
        {
            var room = await _roomRepository.GetByIdAsync(roomId);
            if (room == null || room.Status != RoomStatus.Available)
                return false;

            var customer = await _customerRepository.GetByIdAsync(customerId);
            if (customer == null)
                return false;

            decimal basePrice = room.PricePerNight * duration; // ✅ Oda fiyatı gün üzerinden hesaplandı
            decimal finalPrice = await _discountService.CalculateDiscountAsync(DateTime.UtcNow, startDate, basePrice); // ✅ Erken rezervasyon indirimi hesaplandı

            var reservation = new Reservation
            {
                CustomerId = customerId,
                RoomId = roomId,
                StartDate = startDate,
                EndDate = startDate.AddDays(duration),
                Package = package,
                Status = ReservationStatus.Onaylandi,
                TotalPrice = finalPrice // ✅ İndirimli fiyat atandı
            };

            await _reservationRepository.AddAsync(reservation);
            room.Status = RoomStatus.Occupied;
            await _roomRepository.UpdateAsync(room);

            return true;
        }

    }
}
