﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class ExtraExpenseManager : BaseManager<ExtraExpenseDto, ExtraExpense>, IExtraExpenseManager
    {
        private readonly IExtraExpenseRepository  _extraExpenseRepository;
        private readonly IMapper _mapper;

        public ExtraExpenseManager(IExtraExpenseRepository extraExpenseRepository,IMapper mapper):base(extraExpenseRepository,mapper)
        {
            _extraExpenseRepository = extraExpenseRepository;
            _mapper = mapper;

        }

        // 1️⃣ Yeni Ekstra Harcama Ekle
        public async Task AddExtraExpenseAsync(int customerId, decimal unitPrice, string description)
        {
            var extraExpense = new ExtraExpense
            {
                CustomerId = customerId,
                UnitPrice = unitPrice,
                Description = description,
                ExpenseDate = DateTime.UtcNow
            };

            await _extraExpenseRepository.AddAsync(extraExpense);
        }

        // 2️⃣ Müşterinin Ekstra Harcamalarını Getir
        public async Task<List<ExtraExpense>> GetExtraExpensesByCustomerAsync(int customerId)
        {
            return (await _extraExpenseRepository.GetAllAsync(e => e.CustomerId == customerId)).ToList();
        }
    }
}
