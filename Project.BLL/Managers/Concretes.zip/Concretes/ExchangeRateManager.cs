﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class ExchangeRateManager : BaseManager<ExchangeRateDto, ExchangeRate>, IExchangeRateManager
    {
        private readonly IExchangeRateRepository  _exchangeRateRepository;
        private readonly IMapper _mapper;

        public ExchangeRateManager(IExchangeRateRepository exchangeRateRepository, IMapper mapper) : base(exchangeRateRepository, mapper)
        {
            _exchangeRateRepository = exchangeRateRepository;
            _mapper = mapper;
        }

        // 2️⃣ Para Birimini Çevir
        public async Task<decimal> ConvertCurrencyAsync(decimal amount, Currency from, Currency to)
        {
            if (from == to)
                return amount; // Aynı para birimi ise dönüşüm gereksiz

            var latestRate = (await _exchangeRateRepository.GetAllAsync(r => r.FromCurrency == from && r.ToCurrency == to))
                             .OrderByDescending(r => r.Date)
                             .FirstOrDefault();

            if (latestRate == null)
                throw new Exception("Döviz kuru bulunamadı.");

            return amount * latestRate.Rate; // ✅ Döviz çevirme işlemi
        }

        // 1️⃣ Döviz Kuru Güncelle
        public async Task UpdateExchangeRateAsync(Currency from, Currency to, decimal rate)
        {
            var existingRate = (await _exchangeRateRepository.GetAllAsync(r => r.FromCurrency == from && r.ToCurrency == to))
                               .OrderByDescending(r => r.Date)
                               .FirstOrDefault();

            if (existingRate != null)
            {
                existingRate.Rate = rate;
                existingRate.Date = DateTime.UtcNow;
                await _exchangeRateRepository.UpdateAsync(existingRate);
            }
            else
            {
                var newRate = new ExchangeRate
                {
                    FromCurrency = from,
                    ToCurrency = to,
                    Rate = rate,
                    Date = DateTime.UtcNow
                };

                await _exchangeRateRepository.AddAsync(newRate);
            }
        }

    }
}
