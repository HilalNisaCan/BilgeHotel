﻿using AutoMapper;
using Castle.Core.Resource;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.BLL.Services;
using Project.BLL.Services.abstracts;
using Project.BLL.Services.Concretes;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class CustomerManager : BaseManager<CustomerDto, Customer>, ICustomerManager
    {
        private readonly ICustomerRepository _customerRepository;
        private readonly IReservationRepository _reservationRepository;
        private readonly ITCKimlikDogrulamaService _tcKimlikDogrulamaService;
        private readonly IMapper _mapper;
        public CustomerManager(ICustomerRepository customerRepository, IMapper mapper,IReservationRepository reservationRepository,ITCKimlikDogrulamaService tCKimlikDogrulamaService) : base(customerRepository, mapper)
        {
            _customerRepository = customerRepository;
            _reservationRepository = reservationRepository;
            _tcKimlikDogrulamaService = tCKimlikDogrulamaService;
            _mapper = mapper;
        }

        // 1️⃣ Müşteri Bilgilerini Getir
        public async Task<Customer> GetCustomerByIdAsync(int customerId)
        {
            return await _customerRepository.GetByIdAsync(customerId);
        }


        // 1️⃣ Müşterinin Rezervasyon Geçmişini Getir
        public async Task<List<Reservation>> GetCustomerReservationsAsync(int customerId)
        {
            return (await _reservationRepository.GetAllAsync(r => r.CustomerId == customerId))
                   .OrderByDescending(r => r.StartDate) // ✅ En son yapılan rezervasyonları önce getir
                   .ToList();
        }

        // 3️⃣ Sadakat Puanını Getir
        public async Task<decimal> GetLoyaltyPointsAsync(int customerId)
        {
            var customer = await _customerRepository.GetByIdAsync(customerId);
            return customer?.LoyaltyPoints ?? 0m; // ✅ `decimal` türünde döndür
        }

       

        public async Task<Customer> GetOrCreateCustomerAsync(int userId, string identityNumber ,string firstName,string lastName,int birthYear)
        {
            var existingCustomer = (await _customerRepository.GetAllAsync(c => c.IdentityNumber == identityNumber)).FirstOrDefault();

            if (existingCustomer != null)
                return existingCustomer;

            // ✅ Kimlik doğrulama işlemi
            bool isValid = await _tcKimlikDogrulamaService.ValidateIdentityAsync(identityNumber, firstName, lastName, birthYear);

            if (!isValid)
                throw new Exception("Kimlik doğrulama başarısız. Lütfen bilgilerinizi kontrol edin.");

            var newCustomer = new Customer
            {
                UserId = userId,
                IdentityNumber = identityNumber,
                LoyaltyPoints = 0,
                CreatedDate = DateTime.UtcNow
            };

            await _customerRepository.AddAsync(newCustomer);
            return newCustomer;
        }

        public async Task UpdateLoyaltyPointsAsync(int customerId, decimal points)
        {
            var customer = await _customerRepository.GetByIdAsync(customerId);
            if (customer == null) throw new Exception("Müşteri bulunamadı.");

            customer.LoyaltyPoints += points; // ✅ Burada sorun olmaz çünkü LoyaltyPoints zaten decimal

            await _customerRepository.UpdateAsync(customer);
        }
    }
}
