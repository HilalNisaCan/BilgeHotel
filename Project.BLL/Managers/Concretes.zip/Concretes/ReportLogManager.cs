﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Project.BLL.Managers.Concretes
{
    public class ReportLogManager : BaseManager<ReportLogDto, ReportLog>, IReportLogManager
    {
        private readonly IReportLogRepository _reportRepository;
        private readonly IReservationRepository _reservationRepository;
        private readonly IPaymentRepository _paymentRepository;
        private readonly IMapper _mapper;


        public ReportLogManager(IReportLogRepository reportRepository, IReservationRepository reservationRepository, IPaymentRepository paymentRepository, IMapper mapper) : base(reportRepository, mapper)
        {
            _reportRepository = reportRepository;
            _reservationRepository = reservationRepository;
            _paymentRepository = paymentRepository;

        }

        public Task GenerateDailyCustomerReportAsync()
        {
            throw new NotImplementedException();
        }

        // 2️⃣ Finansal Rapor Oluştur
        public async Task GenerateFinancialReportAsync()
        {
            var payments = await _paymentRepository.GetAllAsync(p => p.PaymentDate.Date == DateTime.UtcNow.Date);
            decimal totalRevenue = payments.Sum(p => p.TotalAmount);

            var report = new ReportLog
            {
                ReportType = ReportType.MaliRapor,
                CreatedDate = DateTime.UtcNow,
                Status = ReportStatus.Basarili,
                ReportData = $"Bugünkü toplam gelir: {totalRevenue:C}"
            };

            await _reportRepository.AddAsync(report);
        }

        // 1️⃣ XML Raporu Oluştur
        public async Task<string> GenerateXmlReportAsync(ReportType reportType)
        {
            var reports = await _reportRepository.GetAllAsync(r => r.ReportType == reportType);
            XDocument xmlDocument = new XDocument(
            new XElement("Reports",
             reports.Select(report =>
                 new XElement("Report",
                     new XElement("Id", report.Id),
                     new XElement("CreatedDate", report.CreatedDate),
                     new XElement("Status", report.Status.ToString()),
                     new XElement("Data", report.ReportData)
                 )
              )
            )
          );
            string xmlString = xmlDocument.ToString();
            return xmlString;
        }
    

        // 3️⃣ Belirli Türdeki Raporları Getir
        public async Task<List<ReportLog>> GetReportsAsync(ReportType reportType)
        {
            return (await _reportRepository.GetAllAsync(r => r.ReportType == reportType)).ToList();
        }

        public async Task<bool> SendXmlReportToAuthoritiesAsync(string xmlData)
        {
            using (var httpClient = new HttpClient())
            {
                var content = new StringContent(xmlData, Encoding.UTF8, "application/xml");

                HttpResponseMessage response = await httpClient.PostAsync("https://valilik.gov.tr/xml-report-endpoint", content);

                return response.IsSuccessStatusCode;
            }
        }
    }
}
