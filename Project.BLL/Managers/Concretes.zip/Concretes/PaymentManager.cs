﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class PaymentManager : BaseManager<PaymentDto, Payment>, IPaymentManager
    {
        private readonly IRepository<Payment> _paymentRepository;
        private readonly IRepository<ExtraExpense> _expenseRepository;
        private readonly IRepository<OrderDetail> _orderDetailRepository;
        private readonly IMapper _mapper;

        public PaymentManager(IPaymentRepository paymentRepo, IExtraExpenseRepository expenseRepo,IOrderDetailRepository orderDetailRepo, IMapper mapper) : base(paymentRepo, mapper)
        {
            _paymentRepository = paymentRepo;
             _expenseRepository = expenseRepo;
             _orderDetailRepository = orderDetailRepo;
            _mapper= mapper;
        }


        public async Task<decimal> CalculateTotalBillAsync(int reservationId)
        {
            var payments = await _paymentRepository.GetAllAsync(p => p.ReservationId == reservationId);
            var extraExpenses = (await _expenseRepository.GetAllAsync(e => e.ReservationId == reservationId)).Sum(e => e.UnitPrice);
            var orders = (await _orderDetailRepository.GetAllAsync(o => o.ReservationId == reservationId)).Sum(o => o.UnitPrice);

            return payments.Sum(p => p.TotalAmount) + extraExpenses + orders;
        }


        public async Task<bool> ProcessPaymentAsync(int reservationId, decimal amount, PaymentMethod method)
        {
            var payment = new Payment
            {
                ReservationId = reservationId,
                TotalAmount = amount,
                PaymentMethod = method,
                Status = (DataStatus)PaymentStatus.Tamamlandi
            };

            await _paymentRepository.AddAsync(payment);
            return true;
        }
    }
}
