﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class ComplaintLogManager : BaseManager<ComplaintLogDto, ComplaintLog>, IComplaintManager
    {
        private readonly IComplaintLogRepository _complaintRepository;

        public ComplaintLogManager(IComplaintLogRepository  complaintRepository, IMapper mapper) : base(complaintRepository, mapper)
        {
            _complaintRepository = complaintRepository;
        }


        // 1️⃣ Yeni Şikayet Ekle
        public async Task<int> AddComplaintAsync(int customerId, string subject, string description)
        {
            var complaint = new ComplaintLog
            {
                CustomerId = customerId,
                Subject = subject,
                Description = description,
                Status = ComplaintStatus.Pending,
                CreatedDate = DateTime.UtcNow
            };

            await _complaintRepository.AddAsync(complaint);
            return complaint.Id;
        }

        // 2️⃣ Belirli Durumdaki Şikayetleri Getir
        public async Task<List<ComplaintLog>> GetComplaintsAsync(ComplaintStatus status)
        {
            return (await _complaintRepository.GetAllAsync(c => c.Status == status)).ToList();
        }

        // 3️⃣ Şikayet Durumunu Güncelle
        public async Task UpdateComplaintStatusAsync(int complaintId, ComplaintStatus status)
        {
            var complaint = await _complaintRepository.GetByIdAsync(complaintId);
            if (complaint == null) throw new Exception("Şikayet bulunamadı.");

            complaint.Status = status;
            await _complaintRepository.UpdateAsync(complaint);
        }
    }
}
