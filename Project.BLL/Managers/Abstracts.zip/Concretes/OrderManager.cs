﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class OrderManager : BaseManager<OrderDto, Order>, IOrderManager
    {
        private readonly IOrderRepository _orderRepository;
        private readonly IOrderDetailRepository _orderDetailRepository;
        private readonly IMapper _mapper;


        public OrderManager(IOrderRepository orderRepository, IOrderDetailRepository orderDetailRepository, IMapper mapper):base(orderRepository,mapper)
        {
            _orderRepository = orderRepository;
            _orderDetailRepository = orderDetailRepository;
            _mapper = mapper;
        }
        // 1️⃣ Yeni Sipariş Oluştur
        public async Task<int> CreateOrderAsync(int customerId, List<OrderDetail> orderDetails)
        {
            var order = new Order
            {
                UserId = customerId,
                OrderDate = DateTime.UtcNow,
                Status = OrderStatus.Beklemede
            };

            await _orderRepository.AddAsync(order);

            foreach (var detail in orderDetails)
            {
                detail.OrderId = order.Id;
                await _orderDetailRepository.AddAsync(detail);
            }

            return order.Id;
        }

        // 2️⃣ Müşterinin Geçmiş Siparişlerini Getir
        public async Task<List<Order>> GetOrdersByCustomerAsync(int customerId)
        {
            return (await _orderRepository.GetAllAsync(o => o.UserId == customerId)).ToList();
        }

        // 3️⃣ Sipariş Durumunu Güncelle
        public async Task UpdateOrderStatusAsync(int orderId, OrderStatus status)
        {
            var order = await _orderRepository.GetByIdAsync(orderId);
            if (order == null) throw new Exception("Sipariş bulunamadı.");

            order.Status = status;
            await _orderRepository.UpdateAsync(order);
        }
    }
}
