﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.ContextClasses;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows; // MessageBox Kullanımı İçin



namespace Project.BLL.Managers.Concretes
{
    public class RoomManager : BaseManager<RoomDto, Room>, IRoomManager
    {
        private readonly IRepository<Room> _roomRepository;
        private readonly IRepository<RoomCleaningSchedule> _cleaningRepository;
        private readonly IMapper _mapper;

        public RoomManager(IRoomRepository roomRepository, IRoomCleaningScheduleRepository cleaningRepository,IMapper mapper):base(roomRepository ,mapper)
        {
            _roomRepository = roomRepository;
            _cleaningRepository = cleaningRepository;
            _mapper = mapper;
        }

        // 2️⃣ Oda Durumu Güncelleme
        public async Task ChangeRoomStatusAsync(int roomId, RoomStatus status)
        {
            var room = await _roomRepository.GetByIdAsync(roomId);
            if (room == null) throw new Exception("Oda bulunamadı.");

            room.Status = status;
            await _roomRepository.UpdateAsync(room);
        }


        public async Task<List<Room>> GetAvailableRoomsAsync()
        {
            try
            {
                using var dbContext = new MyContext(new DbContextOptionsBuilder<MyContext>()
                    .UseSqlServer("Server=HILALNISA\\SQLEXPRESS;Database=BilgeHotel;Trusted_Connection=True;").Options);

                // 🔍 Veritabanına bağlan ve boş odaları getir
                var rooms = await dbContext.Rooms
                    .Where(r => r.Status == RoomStatus.Available)
                    .ToListAsync();

                return rooms; // Veriyi UI katmanına döndür
            }
            catch (Exception ex)
            {
                return null; // Eğer hata olursa UI katmanında kontrol edeceğiz
            }
        }



        // 3️⃣ Odayı Temizliğe Planlama
        public async Task ScheduleCleaningAsync(int roomId, DateTime cleaningDate)
        {
            var cleaningSchedule = new RoomCleaningSchedule
            {
                RoomId = roomId,
                CleaningDate = cleaningDate,
                Status = RoomStatus.Cleaning


            };

            await _cleaningRepository.AddAsync(cleaningSchedule);
            await ChangeRoomStatusAsync(roomId, RoomStatus.Cleaning); // ✅ Oda durumu da temizliğe çekildi

            static RoomStatus GetCleaning()
            {
                return RoomStatus.Cleaning; // ✅ Hata düzeltilmiş;
            }
        }

    }
}
