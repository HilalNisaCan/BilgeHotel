﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Dal.Repositories.Concretes;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class CampaignManager : BaseManager<CampaignDto, Campaign>, ICampainManager
    {
        private readonly ICampaignRepository _campaignRepository;
        private readonly IMapper _mapper;
        public CampaignManager(ICampaignRepository campaignRepository, IMapper mapper) : base(campaignRepository, mapper)
        {
            _campaignRepository = campaignRepository;
            _mapper=mapper; 
        }

        public async Task<int> AddCampaignAsync(string name, string productImagePath, ReservationPackage package, decimal discountPercentage, int validityDays, DateTime startDate, DateTime endDate)
        {
            var campaign = new Campaign
            {
                Name = name, // ✅ Title yerine Name kullanıldı
                ProductImagePath = productImagePath, // ✅ Kampanya görseli
                Package = package, // ✅ Kampanya uygulanacak rezervasyon paketi
                DiscountPercentage = discountPercentage, // ✅ Kampanya indirimi
                ValidityDays = validityDays, // ✅ Kampanya geçerlilik süresi
                StartDate = startDate,
                EndDate = endDate,
                Status = CampaignStatus.Upcoming, // ✅ Yeni eklenen kampanyalar Upcoming olarak başlar
                IsActive = true // ✅ Varsayılan olarak aktif kampanya
            };

            await _campaignRepository.AddAsync(campaign);
            return campaign.Id;
        }

        public Task<int> AddCampaignAsync(string title, string description, DateTime startDate, DateTime endDate)
        {
            throw new NotImplementedException();
        }

        // 2️⃣ Aktif Kampanyaları Getir
        public async Task<List<Campaign>> GetActiveCampaignsAsync()
        {
            return (await _campaignRepository.GetAllAsync(c => c.Status == CampaignStatus.Active)).ToList();
        }

        // 3️⃣ Kampanya Durumunu Güncelle
        public async Task UpdateCampaignStatusAsync(int campaignId, CampaignStatus status)
        {
            var campaign = await _campaignRepository.GetByIdAsync(campaignId);
            if (campaign == null) throw new Exception("Kampanya bulunamadı.");

            campaign.Status = status;
            await _campaignRepository.UpdateAsync(campaign);
        }
    }
}
