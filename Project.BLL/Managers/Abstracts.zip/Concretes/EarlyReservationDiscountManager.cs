﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class EarlyReservationDiscountManager : BaseManager<EarlyReservationDiscountDto, EarlyReservationDiscount>, IEarlyReservationDiscountManager
    {
        private readonly IEarlyReservationDiscountRepository _discountRepository;
        private readonly IMapper _mapper;

        public EarlyReservationDiscountManager(IEarlyReservationDiscountRepository discountRepository, IMapper mapper) : base(discountRepository, mapper)
        {
            _discountRepository = discountRepository;
            _mapper = mapper;
        }

        // 1️⃣ Erken Rezervasyon İndirimi Hesapla
        public async Task<decimal> CalculateDiscountAsync(DateTime reservationDate, DateTime checkInDate, decimal basePrice)
        {
            int daysBeforeCheckIn = (checkInDate - reservationDate).Days;

            var applicableDiscount = (await _discountRepository.GetAllAsync(d => daysBeforeCheckIn >= d.ValidityDays))
                                   .OrderByDescending(d => d.ValidityDays)
                                   .FirstOrDefault();

            if (applicableDiscount == null)
                return basePrice; // ✅ İndirim yoksa normal fiyat döndür

            decimal discountAmount = basePrice * (applicableDiscount.DiscountPercentage / 100);
            return basePrice - discountAmount; // ✅ İndirimli fiyatı döndür
        }
    }
}
