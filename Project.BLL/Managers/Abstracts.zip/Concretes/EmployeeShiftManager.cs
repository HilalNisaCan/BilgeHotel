﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class EmployeeShiftManager : BaseManager<EmployeeShiftDto, EmployeeShift>, IEmployeeShiftManager
    {
        private readonly IRepository<Employee> _employeeRepository;
        private readonly IRepository<EmployeeShift> _shiftRepository;
        private readonly IRepository<EmployeeShiftAssignment> _shiftAssignmentRepository;
        private readonly IMapper _mapper;

        public EmployeeShiftManager(IEmployeeRepository employeeRepo,IEmployeeShiftAssignmentRepository  shiftAssignmentRepo,IEmployeeShiftRepository shiftRepository,IMapper mapper):base(employeeRepo,mapper)
        {
            _employeeRepository = employeeRepo;
            _shiftAssignmentRepository = shiftAssignmentRepo;
            _mapper = mapper;
        }

        public async Task<bool> AssignShiftAsync(int employeeId, DateTime shiftStart, DateTime shiftEnd)
        {
            var employee = await _employeeRepository.GetByIdAsync(employeeId);
            if (employee == null)
                return false;

            // Yeni vardiya oluştur
            var shift = new EmployeeShift
            {
                ShiftStart = shiftStart,
                ShiftEnd = shiftEnd
            };
            await _shiftRepository.AddAsync(shift);

            // Çalışana vardiya ataması yap
            var shiftAssignment = new EmployeeShiftAssignment
            {
                EmployeeId = employeeId,
                EmployeeShiftId = shift.Id  // Yeni oluşturulan vardiya ID'si
            };

            await _shiftAssignmentRepository.AddAsync(shiftAssignment);
            return true;
        }


        public async Task<decimal> CalculateSalaryAsync(int employeeId)
        {
            var employee = await _employeeRepository.GetByIdAsync(employeeId);
            if (employee == null) return 0;

            // Çalışanın atandığı vardiyaları getir
            var shiftAssignments = await _shiftAssignmentRepository.GetAllAsync(sa => sa.EmployeeId == employeeId);
            var shiftIds = shiftAssignments.Select(sa => sa.EmployeeShiftId).ToList();
            var shifts = await _shiftRepository.GetAllAsync(s => shiftIds.Contains(s.Id));

            // Toplam çalışma saatlerini hesapla
            decimal totalHours = shifts.Sum(s => (decimal)(s.ShiftEnd - s.ShiftStart).TotalHours);

            return totalHours * employee.HourlyWage;
        }
    }
}
