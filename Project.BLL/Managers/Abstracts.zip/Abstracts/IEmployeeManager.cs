﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IEmployeeManager : IManager<EmployeeDto, Employee>
    {
        Task CalculateSalaryAsync(int employeeId);// Çalışanın maaşını hesapla(Saatlik/Aylık).
        Task TrackOvertimeAsync(int employeeId, int hours);// Fazla mesai kaydet.
        Task AssignShiftAsync(int employeeId, int shiftId);// Çalışana vardiya ata.
    }
}
