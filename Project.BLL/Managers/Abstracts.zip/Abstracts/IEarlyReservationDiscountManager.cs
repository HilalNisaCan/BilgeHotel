﻿using Project.BLL.DtoClasses;
using Project.BLL.Managers.Concretes;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IEarlyReservationDiscountManager:IManager<EarlyReservationDiscountDto,EarlyReservationDiscount>
    {
        Task<decimal> CalculateDiscountAsync(DateTime reservationDate, DateTime checkInDate, decimal basePrice); // ✅ İndirim hesapla
    }
}
