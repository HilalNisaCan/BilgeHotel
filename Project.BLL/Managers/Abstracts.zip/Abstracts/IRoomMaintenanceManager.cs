﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IRoomMaintenanceManager : IManager<RoomMaintenanceDto, RoomMaintenance>
    {
        Task<List<RoomMaintenanceDto>> GetScheduledMaintenancesAsync();
        Task<bool> CompleteMaintenanceAsync(int maintenanceId);
    }
}
