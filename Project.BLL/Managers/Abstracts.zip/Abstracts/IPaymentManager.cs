﻿using Project.BLL.DtoClasses;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IPaymentManager : IManager<PaymentDto, Payment>
    {
        Task<decimal> CalculateTotalBillAsync(int reservationId);
        Task<bool> ProcessPaymentAsync(int reservationId, decimal amount, PaymentMethod method);


    }
}
