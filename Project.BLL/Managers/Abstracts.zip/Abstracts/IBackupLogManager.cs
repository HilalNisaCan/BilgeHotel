﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IBackupLogManager : IManager<BackupLogDto, BackupLog>
    {
        Task<bool> BackupDatabaseAsync(string backupFolderPath); // ✅ Veritabanı yedekleme
        Task<bool> RestoreDatabaseAsync(string backupFilePath); // ✅ Veritabanı geri yükleme
        Task<List<BackupLog>> GetBackupHistoryAsync(); // ✅ Yedekleme geçmişini getir
    }
}
