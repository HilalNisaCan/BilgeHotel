﻿using Project.BLL.DtoClasses;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IUserManager:IManager<UserDto,User>
    {
        Task<User> AuthenticateUserAsync(string username, string password);
        Task<bool> CreateUserAsync(User user, string password);
        Task<User> GetUserByIdAsync(int id);

        // Yeni eklenen metodlar
        Task<string> GeneratePasswordResetTokenAsync(string email);
        Task<bool> ResetPasswordAsync(string email, string token, string newPassword);
        Task<bool> ChangePasswordAsync(string username, string oldPassword, string newPassword);

    }
}
