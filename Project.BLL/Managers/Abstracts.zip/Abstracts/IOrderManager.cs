﻿using Project.BLL.DtoClasses;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IOrderManager : IManager<OrderDto, Order>
    {
        Task<int> CreateOrderAsync(int customerId, List<OrderDetail> orderDetails);  // Yeni sipariş oluşturur
        Task<List<Order>> GetOrdersByCustomerAsync(int customerId);  // Müşterinin siparişlerini getirir
        Task UpdateOrderStatusAsync(int orderId, OrderStatus status);  // Sipariş durumunu günceller
    }
}
