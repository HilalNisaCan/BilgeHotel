﻿using Project.BLL.DtoClasses;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface ICampainManager : IManager<CampaignDto, Campaign>
    {
        Task<int> AddCampaignAsync(string title, string description, DateTime startDate, DateTime endDate);  // Yeni kampanya ekler
        Task<List<Campaign>> GetActiveCampaignsAsync();  // Aktif kampanyaları getirir
        Task UpdateCampaignStatusAsync(int campaignId, CampaignStatus status);  // Kampanya durumunu günceller
    }
}
