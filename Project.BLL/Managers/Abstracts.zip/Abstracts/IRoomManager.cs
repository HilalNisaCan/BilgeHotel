﻿using Project.BLL.DtoClasses;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Abstracts
{
    public interface IRoomManager : IManager<RoomDto, Room>
    {
        Task<List<Room>> GetAvailableRoomsAsync();  // Boş odaları getirir
        Task ChangeRoomStatusAsync(int roomId, RoomStatus status); // Oda durumunu günceller
        Task ScheduleCleaningAsync(int roomId, DateTime cleaningDate); // Odayı temizliğe planlar

    }
}
