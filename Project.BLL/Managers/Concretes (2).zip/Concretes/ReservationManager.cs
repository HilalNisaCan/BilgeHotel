﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class ReservationManager : BaseManager<ReservationDto, Reservation>, IReservationManager
    {
        private readonly IReservationRepository _reservationRepository;
        private readonly ICustomerRepository _customerRepository;
        private readonly IRoomRepository  _roomRepository;
        private readonly IEarlyReservationDiscountManager _discountService; // ✅ Erken rezervasyon indirimi için
        private readonly IMapper _mapper;

       
        public ReservationManager(IReservationRepository reservationRepo, ICustomerRepository customerRepo, IRoomRepository  roomRepo, IMapper mapper, IEarlyReservationDiscountManager discountService) : base(reservationRepo, mapper)
        {
            _reservationRepository = reservationRepo;
            _customerRepository = customerRepo;
            _roomRepository = roomRepo;
            _mapper = mapper;
            _discountService = discountService;
        }

        public async Task<decimal> CalculateTotalPriceAsync(int roomId)
        {
            var room = await _roomRepository.GetByIdAsync(roomId);
            if (room == null) return 0;

            return room.PricePerNight;
        }

        public async Task<List<Reservation>> GetCustomerReservationsAsync(int customerId)
        {
            return (await _reservationRepository.GetAllAsync(r => r.CustomerId == customerId))
                    .OrderByDescending(r => r.StartDate)
                    .ToList();
        }

        public async Task CancelReservationAsync(int reservationId)
        {
            var reservation = await _reservationRepository.GetByIdAsync(reservationId);
            if (reservation == null || reservation.Status == ReservationStatus.Cancelled)
                return;

            reservation.Status = ReservationStatus.Cancelled;
            await _reservationRepository.UpdateAsync(reservation);

            var room = await _roomRepository.GetByIdAsync(reservation.RoomId);
            if (room != null)
            {
                room.Status = RoomStatus.Available;
                await _roomRepository.UpdateAsync(room);
            }
        }

        public async Task<bool> CheckAvailabilityAsync(int roomId, DateTime startDate, int duration)
        {
            var existingReservations = await _reservationRepository.GetAllAsync(r =>
                r.RoomId == roomId &&
                r.Status != ReservationStatus.Cancelled &&
                ((r.StartDate <= startDate && r.EndDate > startDate) ||
                 (r.StartDate < startDate.AddDays(duration) && r.EndDate >= startDate.AddDays(duration))));

            return !existingReservations.Any();
        }



        public async Task<bool> MakeReservationAsync(int customerId, int roomId, DateTime startDate, int duration, ReservationPackage package)
        {
            if (!await CheckAvailabilityAsync(roomId, startDate, duration))
                return false;

            var customer = await _customerRepository.GetByIdAsync(customerId);
            if (customer == null)
                return false;

            decimal basePrice = await CalculateTotalPriceAsync(roomId);
            decimal finalPrice = await _discountService.CalculateDiscountAsync(customerId, DateTime.UtcNow, startDate, basePrice, package);

            var reservation = new Reservation
            {
                CustomerId = customerId,
                RoomId = roomId,
                StartDate = startDate,
                EndDate = startDate.AddDays(duration),
                Package = package,
                Status = ReservationStatus.Confirmed,
                TotalPrice = finalPrice
            };

            await _reservationRepository.AddAsync(reservation);
            var room = await _roomRepository.GetByIdAsync(roomId);
            room.Status = RoomStatus.Occupied;
            await _roomRepository.UpdateAsync(room);

            return true;
        }

    }
}
