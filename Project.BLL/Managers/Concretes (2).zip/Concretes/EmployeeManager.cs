﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class EmployeeManager : BaseManager<EmployeeDto, Employee>, IEmployeeManager
    {
        private readonly IEmployeeRepository _employeeRepository;
        private readonly IMapper _mapper;

        public EmployeeManager(IEmployeeRepository employeeRepository, IMapper mapper)
            : base(employeeRepository, mapper)
        {
            _employeeRepository = employeeRepository;
            _mapper = mapper;
        }

        public async Task<int> AddEmployeeAsync(EmployeeDto employeeDto)
        {
            var employee = _mapper.Map<Employee>(employeeDto);
            await _employeeRepository.AddAsync(employee);
            return employee.Id;
        }

        public async Task<bool> UpdateEmployeeAsync(int employeeId, EmployeeDto employeeDto)
        {
            var existingEmployee = await _employeeRepository.GetByIdAsync(employeeId);
            if (existingEmployee == null)
                return false;

            _mapper.Map(employeeDto, existingEmployee);
            await _employeeRepository.UpdateAsync(existingEmployee);
            return true;
        }

        public async Task<EmployeeDto> GetEmployeeByIdAsync(int employeeId)
        {
            var employee = await _employeeRepository.GetByIdAsync(employeeId);
            return employee == null ? null : _mapper.Map<EmployeeDto>(employee);
        }

        public async Task<List<EmployeeDto>> GetAllEmployeesAsync()
        {
            var employees = await _employeeRepository.GetAllEmployeesWithUserAsync();
            return _mapper.Map<List<EmployeeDto>>(employees);
        }

        public async Task<bool> DeleteEmployeeAsync(int employeeId)
        {
            var employee = await _employeeRepository.GetByIdAsync(employeeId);
            if (employee == null)
                return false;

            await _employeeRepository.RemoveAsync(employee);
            return true;
        }

        public async Task<decimal> GetManagerSalaryAsync(int employeeId)
        {
            var employee = await _employeeRepository.GetByIdAsync(employeeId);
            if (employee == null || employee.Position != EmployeePosition.Manager)
                throw new Exception("Bu çalışan yönetici değil veya bulunamadı.");

            return employee.HourlyWage * 160; // ✅ Sabit maaş hesaplama (Aylık 160 saat varsayılan)
        }

        public Task AssignShiftAsync(int employeeId, int shiftId, DateTime assignmentDate)
        {
            throw new NotImplementedException();
        }

        public Task<decimal> CalculateSalaryAsync(int employeeId)
        {
            throw new NotImplementedException();
        }

        public Task TrackOvertimeAsync(int employeeId, int extraHours)
        {
            throw new NotImplementedException();
        }
    }
}
