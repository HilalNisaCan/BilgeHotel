﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.BLL.Services.abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class UserManager : BaseManager<UserDto, User>, IUserManager
    {
        private readonly IUserRepository _userRepository;
        private readonly IPasswordHasher _passwordHasher;
        private readonly IMapper _mapper;

        public UserManager(IUserRepository userRepository, IPasswordHasher passwordHasher, IMapper mapper)
            : base(userRepository, mapper)
        {
            _userRepository = userRepository;
            _passwordHasher = passwordHasher;
            _mapper = mapper;
        }

        public async Task<bool> AssignRoleAsync(int userId, UserRole role)
        {
            var user = await _userRepository.GetByIdAsync(userId);
            if (user == null)
                return false;

            user.Role = role;
            await _userRepository.UpdateAsync(user);

            return true;
        }

        public async Task<UserDto> AuthenticateUserAsync(string email, string password)
        {
            var user = await _userRepository.GetAsync(u => u.Email == email);
            if (user == null || !_passwordHasher.VerifyPassword(user.PasswordHash, password))
                throw new Exception("Geçersiz e-posta veya şifre.");

            return _mapper.Map<UserDto>(user);
        }

        public async Task<bool> ChangeUserStatusAsync(int userId, bool isActive)
        {
            var user = await _userRepository.GetByIdAsync(userId);
            if (user == null)
                return false;

            user.IsActivated = isActive;
            await _userRepository.UpdateAsync(user);

            return true;
        }

        public async Task<int> RegisterUserAsync(UserDto userDto, string password)
        {
            var existingUser = await _userRepository.GetAsync(u => u.Email == userDto.Email);
            if (existingUser != null)
                throw new Exception("Bu e-posta adresi zaten kayıtlı.");

            var user = _mapper.Map<User>(userDto);
            user.PasswordHash = _passwordHasher.HashPassword(password);
            user.IsActivated = true; // ✅ Varsayılan olarak aktif kullanıcı oluşturulur

            await _userRepository.AddAsync(user);
            return user.Id;
        }

        public async Task<bool> UpdateUserAsync(int userId, UserDto userDto)
        {
            var user = await _userRepository.GetByIdAsync(userId);
            if (user == null)
                return false;

            _mapper.Map(userDto, user);
            await _userRepository.UpdateAsync(user);

            return true;
        }
    }
}
