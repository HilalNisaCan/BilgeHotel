﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class EarlyReservationDiscountManager : BaseManager<EarlyReservationDiscountDto, EarlyReservationDiscount>, IEarlyReservationDiscountManager
    {
        private readonly IEarlyReservationDiscountRepository _discountRepository;
        private readonly ICustomerRepository _customerRepository;
        private readonly ICampaignRepository _campaignRepository;
        private readonly IReservationRepository _reservationRepository;
        private readonly IMapper _mapper;

        public EarlyReservationDiscountManager(IEarlyReservationDiscountRepository discountRepository, ICustomerRepository customerRepository, ICampaignRepository campaignRepository, IReservationRepository reservationRepository, IMapper mapper)
            : base(discountRepository, mapper)
        {
            _discountRepository = discountRepository;
            _customerRepository = customerRepository;
            _campaignRepository = campaignRepository;
            _reservationRepository = reservationRepository;
            _mapper = mapper;
        }


        public async Task<bool> ApplyDiscountToReservationAsync(int reservationId)
        {
            var reservation = await _reservationRepository.GetByIdAsync(reservationId);
            if (reservation == null)
                return false;

            decimal newPrice = await CalculateDiscountAsync(
                reservation.CustomerId,
                reservation.StartDate,
                reservation.StartDate,
                reservation.TotalPrice,
                reservation.Package);

            reservation.TotalPrice = newPrice;
            await _reservationRepository.UpdateAsync(reservation);

            return true;
        }

        public async Task<decimal> CalculateDiscountAsync(int customerId, DateTime reservationDate, DateTime checkInDate, decimal basePrice, ReservationPackage package)
        {
            int daysBeforeCheckIn = (checkInDate - reservationDate).Days;
            decimal discountRate = 0;

            // ✅ 3 ay önceden yapılan tüm rezervasyonlara %23 indirim
            if (daysBeforeCheckIn >= 90)
            {
                discountRate += 23;
            }
            // ✅ 1 ay önceden yapılan "Her Şey Dahil" rezervasyonlara %18 indirim
            else if (daysBeforeCheckIn >= 30 && package == ReservationPackage.AllInclusive)
            {
                discountRate += 18;
            }
            // ✅ 1 ay önceden yapılan "Tam Pansiyon" rezervasyonlara %16 indirim
            else if (daysBeforeCheckIn >= 30 && package == ReservationPackage.Fullboard)
            {
                discountRate += 16;
            }

            // ✅ Müşteri sadakat puanı kontrolü (100 puan üzeri ekstra %5 indirim)
            var customer = await _customerRepository.GetByIdAsync(customerId);
            if (customer != null && customer.LoyaltyPoints >= 100)
            {
                discountRate += 5;
            }

            // ✅ Kampanyalar kontrolü (Aynı pakete özel aktif kampanyalar varsa ek indirim uygula)
            var activeCampaign = (await _campaignRepository.GetAllAsync(c => c.Package == package && c.IsActive))
                                 .OrderByDescending(c => c.DiscountPercentage)
                                 .FirstOrDefault();

            if (activeCampaign != null)
            {
                discountRate += activeCampaign.DiscountPercentage;
            }

            // ✅ Toplam indirim hesaplama
            decimal discountAmount = basePrice * (discountRate / 100);
            return basePrice - discountAmount; // ✅ İndirimli fiyatı döndür
        }

    }
}
