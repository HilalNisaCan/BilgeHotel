﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class RoomMaintenanceManager : BaseManager<RoomMaintenanceDto, RoomMaintenance>, IRoomMaintenanceManager
    {
        private readonly IRoomMaintenanceRepository _maintenanceRepository;
        private readonly IRoomRepository _roomRepository;
        private readonly IMapper _mapper;

        public RoomMaintenanceManager(IRoomMaintenanceRepository maintenanceRepository, IRoomRepository roomRepository, IMapper mapper)
            : base(maintenanceRepository, mapper)
        {
            _maintenanceRepository = maintenanceRepository;
            _roomRepository = roomRepository;
            _mapper = mapper;
        }

        public async Task<bool> DeleteMaintenanceRecordAsync(int maintenanceId)
        {
            var maintenance = await _maintenanceRepository.GetByIdAsync(maintenanceId);
            if (maintenance == null)
                return false;

            await _maintenanceRepository.RemoveAsync(maintenance);
            return true;
        }

        public async Task<List<RoomMaintenanceDto>> GetMaintenanceHistoryByRoomAsync(int roomId)
        {
            var maintenances = await _maintenanceRepository.GetAllAsync(m => m.RoomId == roomId);
            return _mapper.Map<List<RoomMaintenanceDto>>(maintenances);
        }

        public async Task<int> ScheduleRoomMaintenanceAsync(int roomId, DateTime maintenanceDate, MaintenanceType type)
        {
            var room = await _roomRepository.GetByIdAsync(roomId);
            if (room == null)
                throw new Exception("Oda bulunamadı!");

            var maintenance = new RoomMaintenance
            {
                RoomId = roomId,
                ScheduledDate = maintenanceDate,
                MaintenanceType = type,
                Status = MaintenanceStatus.Scheduled // ✅ Varsayılan olarak planlanmış
            };

            await _maintenanceRepository.AddAsync(maintenance);
            return maintenance.Id;
        }

        public async Task<bool> UpdateMaintenanceStatusAsync(int maintenanceId, MaintenanceStatus status)
        {
            var maintenance = await _maintenanceRepository.GetByIdAsync(maintenanceId);
            if (maintenance == null)
                return false;

            maintenance.Status = status;
            await _maintenanceRepository.UpdateAsync(maintenance);

            // ✅ Eğer bakım tamamlandıysa, odanın durumunu "Kullanılabilir" olarak işaretle
            if (status == MaintenanceStatus.Completed)
            {
                var room = await _roomRepository.GetByIdAsync(maintenance.RoomId);
                room.Status = RoomStatus.Available;
                await _roomRepository.UpdateAsync(room);
            }

            return true;
        }

    }
}
