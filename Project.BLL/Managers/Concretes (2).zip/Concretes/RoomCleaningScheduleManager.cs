﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class RoomCleaningScheduleManager:BaseManager<RoomCleaningScheduleDto,RoomCleaningSchedule>,IRoomCleaningScheduleManager
    {
        private readonly IRoomCleaningScheduleRepository _cleaningScheduleRepository;
        private readonly IRoomRepository _roomRepository;
        private readonly IMapper _mapper;

        public RoomCleaningScheduleManager(IRoomCleaningScheduleRepository cleaningScheduleRepository, IRoomRepository roomRepository, IMapper mapper)
            : base(cleaningScheduleRepository, mapper)
        {
            _cleaningScheduleRepository = cleaningScheduleRepository;
            _roomRepository = roomRepository;
            _mapper = mapper;
        }

        public async Task<List<RoomCleaningScheduleDto>> GetScheduledCleaningsAsync(DateTime date)
        {
            var cleanings = await _cleaningScheduleRepository.GetAllAsync(c => c.ScheduledDate.Date == date.Date);
            return _mapper.Map<List<RoomCleaningScheduleDto>>(cleanings);
        }

        public async Task<bool> MarkCleaningAsCompletedAsync(int cleaningScheduleId)
        {
            var cleaningSchedule = await _cleaningScheduleRepository.GetByIdAsync(cleaningScheduleId);
            if (cleaningSchedule == null)
                return false;

            cleaningSchedule.CleaningStatus = CleaningStatus.Completed;
            await _cleaningScheduleRepository.UpdateAsync(cleaningSchedule);

            // ✅ Odanın durumunu temiz olarak güncelle
            var room = await _roomRepository.GetByIdAsync(cleaningSchedule.RoomId);
            room.Status = RoomStatus.Available;
            await _roomRepository.UpdateAsync(room);

            return true;
        }

        public async Task<int> ScheduleRoomCleaningAsync(int roomId, DateTime cleaningDate)
        {
            var room = await _roomRepository.GetByIdAsync(roomId);
            if (room == null)
                throw new Exception("Oda bulunamadı!");

            var cleaningSchedule = new RoomCleaningSchedule
            {
                RoomId = roomId,
                ScheduledDate = cleaningDate,
                CleaningStatus = CleaningStatus.Scheduled // ✅ Varsayılan olarak planlanmış
            };

            await _cleaningScheduleRepository.AddAsync(cleaningSchedule);
            return cleaningSchedule.Id;
        }
    }
}
