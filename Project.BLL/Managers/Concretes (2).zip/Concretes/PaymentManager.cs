﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class PaymentManager : BaseManager<PaymentDto, Payment>, IPaymentManager
    {
        private readonly IRepository<Payment> _paymentRepository;
        private readonly IRepository<ExtraExpense> _expenseRepository;
        private readonly IRepository<OrderDetail> _orderDetailRepository;
        private readonly IMapper _mapper;

        public PaymentManager(IPaymentRepository paymentRepo, IExtraExpenseRepository expenseRepo,IOrderDetailRepository orderDetailRepo, IMapper mapper) : base(paymentRepo, mapper)
        {
            _paymentRepository = paymentRepo;
             _expenseRepository = expenseRepo;
             _orderDetailRepository = orderDetailRepo;
            _mapper= mapper;
        }

        public async Task<decimal> CalculateTotalBillAsync(int reservationId)
        {
            var payments = await _paymentRepository.GetAllAsync(p => p.ReservationId == reservationId);
            var extraExpenses = (await _expenseRepository.GetAllAsync(e => e.ReservationId == reservationId)).Sum(e => e.UnitPrice);
            var orders = (await _orderDetailRepository.GetAllAsync(o => o.ReservationId == reservationId)).Sum(o => o.UnitPrice);

            return payments.Sum(p => p.TotalAmount) + extraExpenses + orders;
        }

        public async Task<decimal> GetRemainingBalanceAsync(int reservationId)
        {
            var totalBill = await CalculateTotalBillAsync(reservationId);
            var totalPayments = (await _paymentRepository.GetAllAsync(p => p.ReservationId == reservationId && p.PaymentStatus != PaymentStatus.Cancelled))
                                .Sum(p => p.TotalAmount);

            return totalBill - totalPayments;
        }

        public async Task<bool> ProcessPaymentAsync(int reservationId, decimal amount, PaymentMethod method)
        {
            var remainingBalance = await GetRemainingBalanceAsync(reservationId);
            if (amount > remainingBalance)
                throw new Exception("Ödeme miktarı toplam borçtan fazla olamaz!");

            var payment = new Payment
            {
                ReservationId = reservationId,
                TotalAmount = amount,
                PaymentMethod = method,
                PaymentStatus = remainingBalance - amount == 0 ? PaymentStatus.Completed : PaymentStatus.Pending // ✅ Ödeme tamamlandı mı kontrol et
            };

            await _paymentRepository.AddAsync(payment);
            return true;
        }

        public async Task<bool> RefundPaymentAsync(int paymentId, string reason)
        {
            var payment = await _paymentRepository.GetByIdAsync(paymentId);
            if (payment == null || payment.PaymentStatus == PaymentStatus.Cancelled)
                return false;

            payment.PaymentStatus = PaymentStatus.Refunded;
            payment.CancellationReason = reason;
            payment.LastUpdated = DateTime.UtcNow;

            await _paymentRepository.UpdateAsync(payment);
            return true;
        }

        public async Task UpdatePaymentStatusAsync(int paymentId, PaymentStatus status)
        {
            var payment = await _paymentRepository.GetByIdAsync(paymentId);
            if (payment == null) throw new Exception("Ödeme bulunamadı.");

            payment.PaymentStatus = status;
            await _paymentRepository.UpdateAsync(payment);
        }
    }
}
