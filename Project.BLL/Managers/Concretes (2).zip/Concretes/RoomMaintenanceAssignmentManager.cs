﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class RoomMaintenanceAssignmentManager : BaseManager<RoomMaintenanceAssignmentDto, RoomMaintenanceAssignment>, IRoomMaintenanceAssignmentManager
    {
        private readonly IRoomMaintenanceAssignmentRepository _assignmentRepository;
        private readonly IRoomRepository _roomRepository;
        private readonly IEmployeeRepository _employeeRepository;
        private readonly IMapper _mapper;

        public RoomMaintenanceAssignmentManager(IRoomMaintenanceAssignmentRepository assignmentRepository,
                                                IRoomRepository roomRepository,
                                                IEmployeeRepository employeeRepository,
                                                IMapper mapper)
            : base(assignmentRepository, mapper)
        {
            _assignmentRepository = assignmentRepository;
            _roomRepository = roomRepository;
            _employeeRepository = employeeRepository;
            _mapper = mapper;
        }
        public async Task<int> AssignMaintenanceAsync(int roomId, int maintenanceId, int assignedEmployeeId)
        {
            var room = await _roomRepository.GetByIdAsync(roomId);
            var employee = await _employeeRepository.GetByIdAsync(assignedEmployeeId);

            if (room == null || employee == null)
                throw new Exception("Oda veya çalışan bulunamadı.");

            var assignment = new RoomMaintenanceAssignment
            {
                RoomId = roomId,
                MaintenanceId = maintenanceId,
                AssignedEmployeeId = assignedEmployeeId,
                AssignedDate = DateTime.UtcNow,
                MaintenanceStatus = MaintenanceStatus.Pending // ✅ Yeni bakım atamaları varsayılan olarak beklemede olur
            };

            await _assignmentRepository.AddAsync(assignment);
            return assignment.Id;
        }

        public async Task<bool> CompleteMaintenanceAsync(int assignmentId)
        {
            var assignment = await _assignmentRepository.GetByIdAsync(assignmentId);
            if (assignment == null)
                return false;

            assignment.MaintenanceStatus = MaintenanceStatus.Completed; // ✅ Bakım tamamlandı olarak işaretleniyor
            assignment.CompletedDate = DateTime.UtcNow;
            await _assignmentRepository.UpdateAsync(assignment);

            return true;
        }

        public async Task<List<RoomMaintenanceAssignmentDto>> GetRoomMaintenanceAssignmentsAsync(int roomId)
        {
            var assignments = await _assignmentRepository.GetAllAsync(a => a.RoomId == roomId);
            return _mapper.Map<List<RoomMaintenanceAssignmentDto>>(assignments);
        }

        public async Task<bool> RemoveMaintenanceAssignmentAsync(int assignmentId)
        {
            var assignment = await _assignmentRepository.GetByIdAsync(assignmentId);
            if (assignment == null)
                return false;

            await _assignmentRepository.RemoveAsync(assignment);
            return true;
        }
    }
}
