﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.ContextClasses;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Enums;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows; // MessageBox Kullanımı İçin



namespace Project.BLL.Managers.Concretes
{
    public class RoomManager : BaseManager<RoomDto, Room>, IRoomManager
    {
        private readonly IRoomRepository _roomRepository;
        private readonly IRoomCleaningScheduleRepository _cleaningRepository;
        private readonly IRoomMaintenanceRepository _maintenanceRepository;
        private readonly IMapper _mapper;

        public RoomManager(IRoomRepository roomRepository, IRoomCleaningScheduleRepository cleaningRepository,IMapper mapper,IRoomMaintenanceRepository maintenanceRepository):base(roomRepository ,mapper)
        {
            _roomRepository = roomRepository;
            _cleaningRepository = cleaningRepository;
            _maintenanceRepository = maintenanceRepository;
            _mapper = mapper;
        }

        public async Task ChangeRoomStatusAsync(int roomId, RoomStatus status)
        {
            var room = await _roomRepository.GetByIdAsync(roomId);
            if (room == null) throw new Exception("Oda bulunamadı.");

            room.Status = status;
            await _roomRepository.UpdateAsync(room);
        }

        public async Task<List<Room>> GetAvailableRoomsAsync()
        {
            return (await _roomRepository.GetAllAsync(r => r.Status == RoomStatus.Available)).ToList();
        }


        public async Task<Room> GetRoomDetailsAsync(int roomId)
        {
            return await _roomRepository.GetByIdAsync(roomId) ?? throw new Exception("Oda bulunamadı.");
        }

        public async Task MarkRoomAsCleanedAsync(int roomId)
        {
            var room = await _roomRepository.GetByIdAsync(roomId);
            if (room == null) throw new Exception("Oda bulunamadı.");

            room.IsCleaned = true;
            room.Status = RoomStatus.Available;
            await _roomRepository.UpdateAsync(room);
        }

        public async Task ScheduleCleaningAsync(int roomId, DateTime cleaningDate)
        {
            var room = await _roomRepository.GetByIdAsync(roomId);
            if (room == null) throw new Exception("Oda bulunamadı.");

            // Oda statüsünü değiştirme
            room.Status = RoomStatus.Cleaning;
            await _roomRepository.UpdateAsync(room);

            // ✅ Yeni bir temizlik kaydı oluştur
            var cleaningSchedule = new RoomCleaningSchedule
            {
                RoomId = roomId,
                ScheduledDate = cleaningDate,
                CleaningStatus=CleaningStatus.Scheduled,

            };

            await _cleaningRepository.AddAsync(cleaningSchedule);
        }

        public async Task ScheduleMaintenanceAsync(int roomId, DateTime maintenanceDate, MaintenanceType type)
        {
            var maintenance = new RoomMaintenance
            {
                RoomId = roomId,
                ScheduledDate = maintenanceDate,
                MaintenanceType = type,
                Status = MaintenanceStatus.Pending
            };
            await _maintenanceRepository.AddAsync(maintenance);
        }
    }
}
