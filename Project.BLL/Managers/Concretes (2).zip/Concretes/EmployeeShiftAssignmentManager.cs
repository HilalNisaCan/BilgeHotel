﻿using AutoMapper;
using Project.BLL.DtoClasses;
using Project.BLL.Managers.Abstracts;
using Project.Dal.Repositories.Abstracts;
using Project.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.Managers.Concretes
{
    public class EmployeeShiftAssignmentManager : BaseManager<EmployeeShiftAssignmentDto, EmployeeShiftAssignment>, IEmployeeShiftAssignmentManager
    {
        private readonly IEmployeeShiftAssignmentRepository _assignmentRepository;
        private readonly IEmployeeRepository _employeeRepository;
        private readonly IEmployeeShiftRepository _employeeShiftRepository;
        private readonly IMapper _mapper;

        public EmployeeShiftAssignmentManager(IEmployeeShiftAssignmentRepository assignmentRepository,
                                              IEmployeeRepository employeeRepository,
                                              IEmployeeShiftRepository employeeShiftRepository,
                                              IMapper mapper)
            : base(assignmentRepository, mapper)
        {
            _assignmentRepository = assignmentRepository;
            _employeeRepository = employeeRepository;
            _employeeShiftRepository = employeeShiftRepository;
            _mapper = mapper;
        }

        public async Task<int> AssignShiftAsync(int employeeId, int shiftId)
        {
            var employee = await _employeeRepository.GetByIdAsync(employeeId);
            var shift = await _employeeShiftRepository.GetByIdAsync(shiftId);

            if (employee == null || shift == null)
                throw new Exception("Çalışan veya vardiya bulunamadı.");

            // ✅ Aynı vardiya tekrar atanamaz
            var existingAssignment = await _assignmentRepository.GetAsync(a => a.EmployeeId == employeeId && a.EmployeeShiftId == shiftId);
            if (existingAssignment != null)
                throw new Exception("Bu çalışan zaten bu vardiyaya atanmış.");

            var assignment = new EmployeeShiftAssignment
            {
                EmployeeId = employeeId,
                EmployeeShiftId = shiftId,
                AssignedDate = DateTime.UtcNow
            };

            await _assignmentRepository.AddAsync(assignment);
            return assignment.Id;
        }
        public async Task<List<EmployeeShiftAssignmentDto>> GetEmployeeShiftsAsync(int employeeId)
        {
            var assignments = await _assignmentRepository.GetAllAsync(a => a.EmployeeId == employeeId);
            return _mapper.Map<List<EmployeeShiftAssignmentDto>>(assignments);
        }

        public async Task<bool> RemoveShiftAssignmentAsync(int assignmentId)
        {
            var assignment = await _assignmentRepository.GetByIdAsync(assignmentId);
            if (assignment == null)
                return false;

            await _assignmentRepository.RemoveAsync(assignment);
            return true;
        }

        public async Task<bool> ValidateShiftAssignmentAsync(int employeeId, int shiftId)
        {
            var existingAssignment = await _assignmentRepository.GetAsync(a => a.EmployeeId == employeeId && a.EmployeeShiftId == shiftId);
            return existingAssignment == null; // ✅ Eğer kayıt yoksa vardiya atanabilir
        }
    }
}