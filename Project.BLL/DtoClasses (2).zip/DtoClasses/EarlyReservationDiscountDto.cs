﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.DtoClasses
{
    public class EarlyReservationDiscountDto:BaseDto
    {
        public decimal DiscountPercentage { get; set; }
        public DateTime AppliedDate { get; set; }
    }
}
