﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.DtoClasses
{
    public class RoomImageDto : BaseDto
    {
       
        public string ImagePath { get; set; }
    }
}
