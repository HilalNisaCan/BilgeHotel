﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.DtoClasses
{
    public class EmployeeShiftAssignmentDto:BaseDto
    {
        //public int EmployeeId { get; set; }
        //public int EmployeeShiftId { get; set; }
    }
}
