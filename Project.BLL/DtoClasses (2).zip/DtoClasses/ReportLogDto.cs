﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.DtoClasses
{
    public class ReportLogDto:BaseDto
    {
        public string ReportType { get; set; }
        public DateTime CreatedDate { get; set; }
        public string ReportData { get; set; }
    }
}
