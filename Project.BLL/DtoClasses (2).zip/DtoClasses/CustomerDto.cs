﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.DtoClasses
{
    public class CustomerDto:BaseDto
    {
        public string FullName { get; set; }
        public int LoyaltyPoints { get; set; }
        public string IdentityNumber { get; set; }
    }
}
