﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.DtoClasses
{
    public class ExchangeRateApiResponseDto
    {
        public Dictionary<string, decimal> Rates { get; set; } // ✅ API'den gelen döviz verisi
    }
}
