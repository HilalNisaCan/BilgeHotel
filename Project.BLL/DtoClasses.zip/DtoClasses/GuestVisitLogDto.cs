﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.DtoClasses
{
    public class GuestVisitLogDto:BaseDto
    {
        
        public string GuestFullName { get; set; }
        public string GuestIdentityNumber { get; set; }
        public DateTime VisitDate { get; set; }
    }
}
