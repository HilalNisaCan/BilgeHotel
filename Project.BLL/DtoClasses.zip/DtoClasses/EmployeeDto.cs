﻿using Project.Entities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.DtoClasses
{
    public class EmployeeDto:BaseDto
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string IdentityNumber { get; set; }
        public string PhoneNumber { get; set; }
        public string Position { get; set; }
        public decimal Salary { get; set; }
        public int ShiftHours { get; set; }
        public decimal HourlyWage { get; set; }
        public bool IsOvertime { get; set; }
        public decimal OvertimePay { get; set; }
        public bool IsActive { get; set; }
        public DateTime HireDate { get; set; }
        public SalaryType SalaryType { get; set; }
    }
}
