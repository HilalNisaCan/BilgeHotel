﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.DtoClasses
{
    public class OrderDetailDto:BaseDto
    {

        public int ProductId { get; set; } // ✅ Eksik olan ProductId eklendi
        public int Quantity { get; set; } // ✅ Sipariş miktarı
        public decimal UnitPrice { get; set; } // ✅ Ürün birim fiyatı
    }
}
