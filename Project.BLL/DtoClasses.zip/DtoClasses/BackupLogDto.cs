﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.BLL.DtoClasses
{
    public class BackupLogDto:BaseDto
    {
      
        public string FilePath { get; set; }
        public DateTime BackupDate { get; set; }
        public bool IsRestored { get; set; }
    }
}
