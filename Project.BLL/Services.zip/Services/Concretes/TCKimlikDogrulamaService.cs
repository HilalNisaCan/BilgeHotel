﻿using Project.BLL.Services.abstracts;
using ServiceReference1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Project.BLL.Services.Concretes
{
    public class TCKimlikDogrulamaService : ITCKimlikDogrulamaService
    {
        public async Task<bool> ValidateIdentityAsync(string identityNumber, string firstName, string lastName, int birthYear)
        {
            try
            {
                using (var client = new KPSPublicSoapClient(KPSPublicSoapClient.EndpointConfiguration.KPSPublicSoap))
                {
                    var response = await client.TCKimlikNoDogrulaAsync(
                        Convert.ToInt64(identityNumber),
                        firstName.ToUpper(),
                        lastName.ToUpper(),
                        birthYear
                    );

                    return response.Body.TCKimlikNoDogrulaResult;
                }
            }
            catch (Exception)
            {
                return false; // Eğer servis hatası olursa doğrulama başarısız olur
            }
        }
    }
}
